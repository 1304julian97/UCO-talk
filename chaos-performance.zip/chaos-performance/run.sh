#!/usr/bin/env bash
# =============================================================================
#  Experimento de Ingeniería del Caos — rendimiento de la ruta de pagos
#  100 % local. Única dependencia de la máquina: Docker.
#
#  Cuatro fases, en este orden y sin saltarse ninguna:
#
#    1-baseline-v1   v1, proveedor sano   -> se establece el estado estable
#    2-chaos-v1      v1, +500 ms latencia -> se falsa la hipótesis (el hallazgo)
#    3-baseline-v2   v2, proveedor sano   -> se verifica que no hubo regresión
#    4-chaos-v2      v2, +500 ms latencia -> se evidencia la solución
#
#  La fase 3 es la que casi todo el mundo omite, y es la que evita el error
#  clásico: arreglar el caso degradado y romper el caso normal.
#
#  Uso:
#    ./setup.sh           UNA vez: trae los fuentes originales del repositorio
#    ./run.sh up          levanta todo y compila la imagen (hacerlo ANTES)
#    ./run.sh all         las cuatro fases (~7 min con DURATION=60s)
#    ./run.sh demo        solo fases 2 y 4 (~4 min) — para la charla
#    ./run.sh 1|2|3|4     una fase suelta
#    ./run.sh latency on|off    pone o quita la toxina a mano
#    ./run.sh down        apaga y limpia
# =============================================================================
set -euo pipefail

cd "$(dirname "$0")"

TOXI="http://localhost:8474"
APP="http://localhost:8080"
GRAFANA="http://localhost:3000"
PROM="http://localhost:9090"

DURATION="${DURATION:-60s}"
ARRIVAL_RATE="${ARRIVAL_RATE:-60}"
LATENCY_MS="${LATENCY_MS:-500}"
JITTER_MS="${JITTER_MS:-100}"

mkdir -p results

log()  { printf '\n\033[1;36m▶ %s\033[0m\n' "$*"; }
note() { printf '  \033[2m%s\033[0m\n' "$*"; }

# -----------------------------------------------------------------------------
# Chequeo previo
#
# Docker falla con un "failed to compute cache key: /modules not found" cuando
# el contexto de build no tiene el proyecto Scala. Ese mensaje no dice nada
# útil, así que lo atajamos antes con uno que sí.
# -----------------------------------------------------------------------------
preflight() {
  local missing=""
  for f in build.sbt project/build.properties modules/domain modules/server; do
    [ -e "$f" ] || missing="$missing $f"
  done

  if [ -n "$missing" ]; then
    printf '\n\033[1;31m✕ Falta el proyecto Scala en este directorio.\033[0m\n'
    printf '  No se encontró:%s\n\n' "$missing"
    printf '  Estás en: %s\n\n' "$PWD"
    printf '  Esta carpeta trae solo los archivos nuevos y los modificados.\n'
    printf '  Los fuentes originales del repositorio hay que traerlos una vez:\n\n'
    printf '      \033[1m./setup.sh\033[0m                    (clona UCO-talk desde GitHub)\n'
    printf '      \033[1m./setup.sh /ruta/a/UCO-talk\033[0m    (si ya lo tenés clonado)\n\n'
    exit 1
  fi

  # Señal de que setup.sh no corrió: están nuestros archivos pero no los del repo.
  if [ ! -e "modules/domain/src/main/scala/co/edu/uco/xebia/bank/payments/algebras/Payments.scala" ]; then
    printf '\n\033[1;31m✕ Faltan los fuentes originales del repositorio.\033[0m\n'
    printf '  Están los archivos instrumentados, pero no el trait Payments ni los\n'
    printf '  tipos de dominio: la compilación fallaría por símbolos sin resolver.\n\n'
    printf '  Corré primero:  \033[1m./setup.sh\033[0m\n\n'
    exit 1
  fi
}

# -----------------------------------------------------------------------------
# Infraestructura
# -----------------------------------------------------------------------------
compose_up() {
  preflight
  log "levantando el laboratorio (la primera vez compila el proyecto: 3-6 min)"
  docker compose up -d --build
  wait_for_app
  note "app       $APP"
  note "grafana   $GRAFANA   (tablero ya cargado, sin login)"
  note "prometheus $PROM/alerts"
  note "toxiproxy $TOXI"
}

wait_for_app() {
  printf '  esperando a la app'
  for _ in $(seq 1 90); do
    if curl -sf "$APP/health" >/dev/null 2>&1; then printf ' lista\n'; return 0; fi
    printf '.'; sleep 2
  done
  printf '\n'; echo "  la app no arrancó — revisá: docker compose logs bank"; exit 1
}

start_app() {
  local impl="$1"
  preflight
  log "arrancando la app con PAYMENTS_IMPL=$impl"

  # La implementación se persiste en .env en vez de pasarse en línea.
  #
  # Motivo, y costó una corrida entera descubrirlo: docker compose compara la
  # configuración efectiva del servicio en CADA invocación. Con la variable
  # sólo en el entorno de este comando, la siguiente invocación —la de k6— la
  # veía ausente, resolvía el valor por defecto, detectaba divergencia y
  # RECREABA el contenedor bank en pleno arranque de la carga. Resultado: k6
  # golpeando un puerto cerrado, y peor, la fase 4 midiendo v1 sin avisar.
  # En .env el valor es parte del proyecto y todas las invocaciones coinciden.
  printf 'PAYMENTS_IMPL=%s\n' "$impl" > .env

  # --force-recreate: reinicia el proceso, así el caché de tasas arranca FRÍO.
  # Un caché caliente esconde el problema; que arranque frío es parte del diseño.
  docker compose up -d --force-recreate --no-deps bank
  wait_for_app
  verify_impl "$impl"
}

# Confirma contra la app que corre la implementación que creemos.
# Una fase que mide lo que no dice medir es peor que una fase que falla.
verify_impl() {
  local expected="$1" actual
  actual=$(curl -sf "$APP/seed" | sed -n 's/.*"impl":"\([^"]*\)".*/\1/p')
  if [ "$actual" != "$expected" ]; then
    printf '\n\033[1;31m✕ La app dice estar corriendo "%s" y esperábamos "%s".\033[0m\n' \
      "$actual" "$expected"
    printf '  Se aborta: medir la fase equivocada es peor que no medirla.\n\n'
    exit 1
  fi
  note "implementación confirmada: $actual"
}

# -----------------------------------------------------------------------------
# Inyección de fallo
# -----------------------------------------------------------------------------
inject_latency() {
  log "inyectando latencia: +${LATENCY_MS}ms (jitter ${JITTER_MS}ms) hacia el proveedor de tasas"
  curl -sf -X POST "$TOXI/proxies/fx/toxics" \
    -H 'Content-Type: application/json' \
    -d "{\"name\":\"fx_latency\",\"type\":\"latency\",\"stream\":\"downstream\",\"toxicity\":1.0,
         \"attributes\":{\"latency\":${LATENCY_MS},\"jitter\":${JITTER_MS}}}" >/dev/null
  note "inyectada"
}

remove_latency() {
  curl -sf -X DELETE "$TOXI/proxies/fx/toxics/fx_latency" >/dev/null 2>&1 || true
}

# Cortafuegos: pase lo que pase —Ctrl-C incluido— el fallo se retira.
# Un experimento que puede quedarse con el fallo puesto es un incidente.
trap remove_latency EXIT INT TERM

# -----------------------------------------------------------------------------
# Carga
# -----------------------------------------------------------------------------
run_k6() {
  local phase="$1"
  log "generando carga — fase $phase  (${DURATION}, ${ARRIVAL_RATE} ops/s por escenario)"

  # Se registran las marcas de tiempo para que compare.sh pueda consultarle a
  # Prometheus exactamente la ventana de cada fase.
  local start; start=$(date +%s)

  # || true: k6 sale con código 99 cuando un umbral no se cumple. En las fases
  # 2 y 4 eso es el RESULTADO del experimento, no un error del script.
  # --no-deps: sin esto, compose evalúa el `depends_on: bank` del servicio k6 y
  # puede recrear la app justo cuando empieza a medirse.
  PHASE="$phase" DURATION="$DURATION" ARRIVAL_RATE="$ARRIVAL_RATE" \
    docker compose run --rm --no-deps k6 || true

  local end; end=$(date +%s)
  printf '%s %s %s\n' "$phase" "$start" "$end" >> results/phases.txt
}

# -----------------------------------------------------------------------------
# Fases
# -----------------------------------------------------------------------------
phase_1() { remove_latency; start_app v1; run_k6 "1-baseline-v1"; }
phase_2() { start_app v1; inject_latency; run_k6 "2-chaos-v1"; remove_latency; }
phase_3() { remove_latency; start_app v2; run_k6 "3-baseline-v2"; }
phase_4() { start_app v2; inject_latency; run_k6 "4-chaos-v2"; remove_latency; }

case "${1:-all}" in
  up)   compose_up ;;
  down) log "apagando"; remove_latency; docker compose --profile load down -v; rm -f .env ;;

  1) phase_1 ;;
  2) phase_2 ;;
  3) phase_3 ;;
  4) phase_4 ;;

  latency)
    case "${2:-on}" in
      on)  inject_latency; trap - EXIT ;;   # se deja puesta a propósito
      off) remove_latency; note "retirada" ;;
      *)   echo "uso: $0 latency on|off"; exit 1 ;;
    esac
    ;;

  demo)
    # Camino corto para la charla: el hallazgo y la evidencia de la solución.
    # Las líneas base conviene correrlas ANTES de subir al escenario.
    : > results/phases.txt
    phase_2; phase_4
    log "resultado"; ./compare.sh
    ;;

  all)
    : > results/phases.txt
    compose_up
    phase_1; phase_2; phase_3; phase_4
    log "resultado"; ./compare.sh
    ;;

  *) echo "uso: $0 [up|all|demo|1|2|3|4|latency on|off|down]"; echo "     (si es la primera vez: ./setup.sh)"; exit 1 ;;
esac
