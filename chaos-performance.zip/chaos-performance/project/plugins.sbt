addSbtPlugin("org.typelevel"  % "sbt-tpolecat"        % "0.5.7")
addSbtPlugin("org.scalameta"  % "sbt-scalafmt"        % "2.5.6")
// [CAOS] aporta la tarea `stage`, que el Dockerfile usa para empaquetar.
addSbtPlugin("com.github.sbt" % "sbt-native-packager" % "1.11.1")
