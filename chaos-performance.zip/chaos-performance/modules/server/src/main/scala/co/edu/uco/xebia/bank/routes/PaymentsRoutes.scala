package co.edu.uco.xebia.bank.routes

import cats.effect.IO
import org.http4s.*
import org.http4s.circe.CirceEntityCodec.*
import org.http4s.dsl.io.*

import co.edu.uco.xebia.bank.accounts.models.AccountId
import co.edu.uco.xebia.bank.codecs.PaymentCodecs.given
import co.edu.uco.xebia.bank.codecs.{AmountRequest, TransferRequest}
import co.edu.uco.xebia.bank.payments.algebras.Payments
import co.edu.uco.xebia.bank.payments.models.ConversionError
import co.edu.uco.xebia.bank.payments.models.PaymentError

import java.util.UUID

/** Superficie HTTP mínima para poder GENERAR CARGA sobre la ruta de pagos.
  *
  * Sin esto no hay experimento: el repo original solo expone `GET/POST /account`,
  * que ni siquiera toca el proveedor de tasas. El defecto de rendimiento vive en
  * `deposit`/`withdraw`/`transfer`, así que hay que poder invocarlos por HTTP.
  *
  * Mapa de errores deliberado — cada uno tiene un significado distinto para el
  * experimento:
  *   409 → error de negocio legítimo (fondos, moneda). NO cuenta como fallo.
  *   503 → la dependencia de tasas no respondió. SÍ cuenta como fallo.
  * Si se colapsan ambos en 500, el estado estable se vuelve imposible de definir.
  */
object PaymentsRoutes:

  private object UUIDVar:
    def unapply(s: String): Option[UUID] =
      try Some(UUID.fromString(s))
      catch case _: IllegalArgumentException => None

  def routes(payments: Payments): HttpRoutes[IO] = HttpRoutes.of[IO] {

    case req @ POST -> Root / "account" / UUIDVar(id) / "deposit" =>
      req.as[AmountRequest].flatMap { body =>
        payments.deposit(AccountId(id), body.amount, body.conversion).flatMap(Ok(_))
      }.handleErrorWith(toResponse)

    case req @ POST -> Root / "account" / UUIDVar(id) / "withdraw" =>
      req.as[AmountRequest].flatMap { body =>
        payments.withdraw(AccountId(id), body.amount, body.conversion).flatMap(Ok(_))
      }.handleErrorWith(toResponse)

    case req @ POST -> Root / "transfer" =>
      req.as[TransferRequest].flatMap { body =>
        payments.transfer(body.from, body.to, body.amount, body.conversion).flatMap(Ok(_))
      }.handleErrorWith(toResponse)
  }

  private def toResponse(error: Throwable): IO[Response[IO]] =
    error match
      case e: PaymentError.AccountDoesNotExist => NotFound(e.getMessage)
      case e: PaymentError => Conflict(e.getMessage)
      case e: ConversionError => ServiceUnavailable(e.getMessage)
      case e => InternalServerError(Option(e.getMessage).getOrElse("error interno"))
