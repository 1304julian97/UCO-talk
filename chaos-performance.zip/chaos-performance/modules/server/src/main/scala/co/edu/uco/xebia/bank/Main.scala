package co.edu.uco.xebia.bank

import cats.effect.IO
import cats.effect.IOApp
import cats.effect.Resource
import cats.syntax.all.*
import com.comcast.ip4s.*
import io.circe.Json
import org.http4s.HttpRoutes
import org.http4s.circe.CirceEntityCodec.*
import org.http4s.dsl.io.*
import org.http4s.ember.server.EmberServerBuilder

import co.edu.uco.xebia.bank.accounts.algebras.Accounts
import co.edu.uco.xebia.bank.accounts.models.*
import co.edu.uco.xebia.bank.config.AppConfig
import co.edu.uco.xebia.bank.config.PaymentsImpl
import co.edu.uco.xebia.bank.gateway.FrankfurterApi
import co.edu.uco.xebia.bank.gateway.RateProvider
import co.edu.uco.xebia.bank.observability.Metrics
import co.edu.uco.xebia.bank.payments.algebras.*
import co.edu.uco.xebia.bank.payments.models.ConversionPolicy
import co.edu.uco.xebia.bank.persistence.memory.BlockingInMemoryBankPersistence
import co.edu.uco.xebia.bank.routes.{AccountsRoutes, OpsRoutes, PaymentsRoutes}
import co.edu.uco.xebia.bank.shared.*

object Main extends IOApp.Simple:

  /** Cuentas sembradas al arrancar.
    *
    * `MERCHANT` existe para reproducir el patrón real que rompe esta
    * arquitectura: una cuenta CALIENTE. En un banco de verdad es la cuenta de
    * un comercio grande, la de comisiones o la de compensación: miles de
    * operaciones concurrentes contra la MISMA clave. Como el lock es por cuenta,
    * la contención no se reparte — se concentra ahí.
    *
    * Si el generador de carga reparte uniformemente entre 200 cuentas, el
    * problema casi no se ve. Ese es el error clásico de las pruebas de carga:
    * distribución uniforme donde la producción tiene sesgo.
    */
  private val Customers = 50

  /** Abre una cuenta. `AccountName` es un tipo refinado, así que el nombre se
    * valida en tiempo de ejecución y un nombre vacío falla el arranque en vez
    * de propagarse.
    */
  private def newAccount(accounts: Accounts, currency: Currency, name: String): IO[Account] =
    IO.fromEither(AccountName.from(name).leftMap(new IllegalArgumentException(_)))
      .flatMap { accountName =>
        IO.randomUUID.flatMap(owner => accounts.open(CustomerId(owner), currency, accountName))
      }

  private def seed(accounts: Accounts, payments: Payments): IO[(Account, List[Account])] =
    for
      merchant <- newAccount(accounts, Currency.USD, "merchant-hot")
      customers <- (1 to Customers).toList.traverse { i =>
        newAccount(accounts, if i % 2 == 0 then Currency.COP else Currency.USD, s"customer-$i")
      }
      // Saldo inicial en la MISMA moneda de la cuenta: no dispara conversión,
      // así el arranque no depende del proveedor de tasas ni calienta el caché.
      // Que el caché arranque FRÍO es parte del diseño del experimento.
      _ <- (merchant :: customers).traverse_ { account =>
        payments.deposit(
          account = account.id,
          amount = Money(MoneyAmount.applyUnsafe(BigDecimal(1000000000)), account.balance.currency),
          conversion = ConversionPolicy.Reject
        )
      }
    yield (merchant, customers)

  /** `/seed` devuelve las cuentas sembradas y —clave— QUÉ implementación está
    * corriendo. El generador de carga lo verifica antes de medir: sin eso, un
    * contenedor que volvió silenciosamente a v1 produciría una fase 4 preciosa
    * y completamente falsa.
    */
  private def seedRoutes(
      config: AppConfig,
      merchant: Account,
      customers: List[Account]
  ): HttpRoutes[IO] =
    HttpRoutes.of[IO] { case GET -> Root / "seed" =>
      Ok(
        Json.obj(
          "impl" -> Json.fromString(config.paymentsImpl.toString.toLowerCase),
          "merchant" -> Json.fromString(merchant.id.toString),
          "customers" -> Json.arr(customers.map(a => Json.fromString(a.id.toString))*)
        )
      )
    }

  /** El interruptor del experimento.
    *
    * Las dos ramas construyen el MISMO tipo `Payments` y quedan detrás de las
    * mismas rutas HTTP. Lo único que cambia entre la fase 2 y la fase 4 es cuál
    * de las dos se instancia — por eso la comparación es un experimento
    * controlado y no dos mediciones sueltas.
    */
  private def buildPayments(
      config: AppConfig,
      persistence: BlockingInMemoryBankPersistence,
      metrics: Metrics
  ): Resource[IO, Payments] =
    config.paymentsImpl match

      // ---- V1: exactamente el código original, solo instrumentado ----
      case PaymentsImpl.V1 =>
        for
          api <- FrankfurterApi.legacy(config.fx, metrics)
          converter <- CurrencyConverter.make(api, config.fx.cacheTtl)
          calculator = MoneyCalculator.make(converter)
        yield PaymentsV1Observed.make(calculator, persistence, metrics)

      // ---- V2: I/O fuera del lock + RateProvider resiliente ----
      case PaymentsImpl.V2 =>
        for
          api <- FrankfurterApi.resilient(config.fx, metrics)
          rates <- RateProvider.make(api, config.fx, metrics)
        yield PaymentsV2.make(rates, persistence, metrics)

  override val run: IO[Unit] =
    AppConfig.load.flatMap { config =>
      val resources: Resource[IO, (Accounts, Payments, Metrics)] =
        for
          metrics <- Metrics.make
          persistence <- Resource.eval(BlockingInMemoryBankPersistence.make)
          accounts = Accounts.make(persistence)
          payments <- buildPayments(config, persistence, metrics)
        yield (accounts, payments, metrics)

      resources.use { case (accounts, payments, metrics) =>
        seed(accounts, payments).flatMap { case (merchant, customers) =>
          val app =
            (OpsRoutes.routes(metrics)
              <+> seedRoutes(config, merchant, customers)
              <+> AccountsRoutes.routes(accounts)
              <+> PaymentsRoutes.routes(payments)).orNotFound

          EmberServerBuilder
            .default[IO]
            .withHost(ipv4"0.0.0.0")
            .withPort(Port.fromInt(config.port).getOrElse(port"8080"))
            .withHttpApp(app)
            .build
            .use { server =>
              IO.println(s"[bank] impl=${config.paymentsImpl} fx=${config.fx.baseUri} en ${server.address}") >>
                IO.never
            }
        }
      }
    }
