package co.edu.uco.xebia.bank.codecs

import io.circe.Decoder
import io.circe.Encoder
import io.circe.Json

import co.edu.uco.xebia.bank.accounts.models.AccountId
import co.edu.uco.xebia.bank.payments.models.ConversionPolicy
import co.edu.uco.xebia.bank.payments.models.Transaction
import co.edu.uco.xebia.bank.shared.Money

final case class AmountRequest(amount: Money, conversion: ConversionPolicy)
final case class TransferRequest(from: AccountId, to: AccountId, amount: Money, conversion: ConversionPolicy)

object PaymentCodecs:
  import JsonCodecs.given

  given Decoder[ConversionPolicy] = Decoder[String].emap {
    case s if s.equalsIgnoreCase("convert") => Right(ConversionPolicy.Convert)
    case s if s.equalsIgnoreCase("reject") => Right(ConversionPolicy.Reject)
    case other => Left(s"conversion inválida: $other")
  }

  given Decoder[AmountRequest] = Decoder.instance { c =>
    for
      amount <- c.get[Money]("amount")
      conversion <- c.getOrElse[ConversionPolicy]("conversion")(ConversionPolicy.Convert)
    yield AmountRequest(amount, conversion)
  }

  given Decoder[TransferRequest] = Decoder.instance { c =>
    for
      from <- c.get[AccountId]("from")
      to <- c.get[AccountId]("to")
      amount <- c.get[Money]("amount")
      conversion <- c.getOrElse[ConversionPolicy]("conversion")(ConversionPolicy.Convert)
    yield TransferRequest(from, to, amount, conversion)
  }

  given Encoder[Transaction] = Encoder.instance {
    case Transaction.Deposit(id, account, amount) =>
      Json.obj(
        "type" -> Json.fromString("Deposit"),
        "id" -> Json.fromString(id.toString),
        "account" -> Json.fromString(account.toString),
        "amount" -> Encoder[Money].apply(amount)
      )
    case Transaction.Withdrawal(id, account, amount) =>
      Json.obj(
        "type" -> Json.fromString("Withdrawal"),
        "id" -> Json.fromString(id.toString),
        "account" -> Json.fromString(account.toString),
        "amount" -> Encoder[Money].apply(amount)
      )
    case Transaction.Transfer(id, from, to, amount) =>
      Json.obj(
        "type" -> Json.fromString("Transfer"),
        "id" -> Json.fromString(id.toString),
        "from" -> Json.fromString(from.toString),
        "to" -> Json.fromString(to.toString),
        "amount" -> Encoder[Money].apply(amount)
      )
  }
