package co.edu.uco.xebia.bank.routes

import cats.effect.IO
import io.prometheus.client.exporter.common.TextFormat
import org.http4s.*
import org.http4s.dsl.io.*
import org.http4s.headers.`Content-Type`

import co.edu.uco.xebia.bank.observability.Metrics

import java.io.StringWriter

/** `/metrics` para Prometheus y `/health` para el balanceador.
  *
  * `/health` responde SIEMPRE 200 mientras el proceso viva y NO consulta al
  * proveedor de tasas. Suena obvio; no lo es. Un health check que llama a sus
  * dependencias convierte una degradación del tercero en un ciclo de reemplazo
  * de tareas: el balanceador saca instancias sanas, la carga se concentra en las
  * que quedan, y el incidente de latencia se vuelve una caída total.
  * Ese es, literalmente, otro experimento de caos que vale la pena correr.
  */
object OpsRoutes:

  // El formato de exposición de Prometheus es texto plano. Se declara con los
  // constructores de http4s en vez de parsear la constante de la librería:
  // el resultado es el mismo y no depende de cómo venga formateada esa cadena.
  private val exposition: `Content-Type` =
    `Content-Type`(MediaType.text.plain, Charset.`UTF-8`)

  def routes(metrics: Metrics): HttpRoutes[IO] = HttpRoutes.of[IO] {
    case GET -> Root / "health" =>
      Ok("ok")

    case GET -> Root / "metrics" =>
      IO {
        val writer = new StringWriter()
        TextFormat.write004(writer, metrics.registry.metricFamilySamples())
        writer.toString
      }.flatMap { body =>
        Ok(body).map(_.withContentType(exposition))
      }
  }
