package co.edu.uco.xebia.bank.payments.algebras

import cats.effect.IO

import co.edu.uco.xebia.bank.gateway.RateProvider
import co.edu.uco.xebia.bank.shared.*

/** Adaptador: expone `RateProvider` con la interfaz `CurrencyConverter` que ya
  * consume `MoneyCalculator`.
  *
  * Sirve para migrar por partes: cualquier código que hoy dependa de
  * `CurrencyConverter` gana single-flight, stale-while-revalidate, breaker y
  * bulkhead sin cambiar una línea. Lo que NO gana es sacar la I/O del lock —
  * eso exige cambiar la forma de `Payments`, y por eso existe `PaymentsV2`.
  */
object CurrencyConverterV2:
  def fromRateProvider(rates: RateProvider): CurrencyConverter =
    new CurrencyConverter:
      override def convert(amount: Money, to: Currency): IO[Money] =
        rates.rateFor(base = amount.currency, quote = to).map { rate =>
          Money(MoneyAmount.applyUnsafe(amount.amount * rate), to)
        }
