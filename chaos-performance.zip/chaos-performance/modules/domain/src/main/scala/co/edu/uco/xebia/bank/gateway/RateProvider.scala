package co.edu.uco.xebia.bank.gateway

import cats.effect.Deferred
import cats.effect.IO
import cats.effect.Ref
import cats.effect.Resource
import cats.effect.std.Semaphore
import cats.effect.std.Supervisor
import cats.syntax.all.*

import co.edu.uco.xebia.bank.config.FxConfig
import co.edu.uco.xebia.bank.observability.Metrics
import co.edu.uco.xebia.bank.payments.models.ConversionError
import co.edu.uco.xebia.bank.shared.Currency
import co.edu.uco.xebia.bank.shared.Rate

import scala.concurrent.duration.FiniteDuration

/** Proveedor de tasas resiliente. Sustituye a `InMemoryCache` + llamada directa.
  *
  * Cuatro patrones, cada uno resolviendo un hallazgo concreto del experimento:
  *
  *   1. SINGLE-FLIGHT (request coalescing)
  *      Hallazgo: con caché fría, N peticiones concurrentes producen N llamadas
  *      al proveedor. Aquí solo una fibra llama; las demás esperan el mismo
  *      `Deferred`. Coste marginal de un pico de tráfico: 1 llamada, no N.
  *
  *   2. STALE-WHILE-REVALIDATE
  *      Hallazgo: el caché original usa TTL duro. Al expirar, TODAS las
  *      peticiones vuelven a origen a la vez → acantilado de latencia
  *      periódico. Aquí una tasa vencida se sigue sirviendo durante
  *      `staleFor` mientras se refresca en segundo plano. Una tasa de cambio
  *      de hace 6 minutos es un problema de negocio aceptable; 3 segundos de
  *      p99 no lo es.
  *
  *   3. CIRCUIT BREAKER
  *      Hallazgo: cuando el proveedor está caído, cada petición paga el
  *      presupuesto completo antes de fallar. Con el breaker abierto se falla
  *      en microsegundos y se libera la última tasa conocida.
  *
  *   4. BULKHEAD
  *      Hallazgo: no había límite de llamadas concurrentes al proveedor. El
  *      semáforo acota cuántas fibras pueden estar bloqueadas ahí a la vez.
  *
  * Nota de diseño: este objeto NO toca ningún lock de cuenta. Esa separación
  * es deliberada — ver `PaymentsV2`.
  */
trait RateProvider:
  /** Devuelve la tasa base->quote, o falla con `ConversionError.RateUnavailable`. */
  def rateFor(base: Currency, quote: Currency): IO[Rate]

object RateProvider:

  private val one: Rate = Rate.applyUnsafe(BigDecimal(1))

  private final case class Key(base: Currency, quote: Currency)
  private final case class Entry(rate: Rate, storedAt: FiniteDuration)

  private enum Breaker:
    case Closed(consecutiveFailures: Int)
    case Open(until: FiniteDuration)

  def make(api: FrankfurterApi, config: FxConfig, metrics: Metrics): Resource[IO, RateProvider] =
    (
      Resource.eval(Ref[IO].of(Map.empty[Key, Entry])),
      Resource.eval(Ref[IO].of(Map.empty[Key, Deferred[IO, Either[Throwable, Option[Rate]]]])),
      Resource.eval(Ref[IO].of[Breaker](Breaker.Closed(0))),
      Resource.eval(Semaphore[IO](config.maxConcurrentCalls.toLong)),
      Supervisor[IO]
    ).mapN { (cache, inFlight, breaker, bulkhead, supervisor) =>

      new RateProvider:

        override def rateFor(base: Currency, quote: Currency): IO[Rate] =
          if base == quote then IO.pure(one)
          else
            val key = Key(base, quote)
            for
              now <- IO.monotonic
              entry <- cache.get.map(_.get(key))
              rate <- entry match
                // Fresca: camino rápido, sin red, sin locks. ~100 ns.
                case Some(e) if now - e.storedAt <= config.freshFor =>
                  metrics.cacheHit().as(e.rate)

                // Vencida pero utilizable: responde ya y refresca por detrás.
                case Some(e) if now - e.storedAt <= config.freshFor + config.staleFor =>
                  metrics.cacheStale() *>
                    supervisor.supervise(singleFlight(key).attempt.void).as(e.rate)

                // No hay nada utilizable: hay que ir a origen.
                case _ =>
                  metrics.cacheMiss() *> singleFlight(key).flatMap {
                    case Some(r) => IO.pure(r)
                    case None => lastResort(key, base, quote)
                  }
            yield rate

        /** Última tasa conocida, por vieja que sea, antes de rechazar la operación.
          * Servir una tasa de ayer suele ser preferible a rechazar el pago; si en
          * tu dominio no lo es, borra esta rama y falla. Es una decisión de
          * negocio, no técnica — pero tiene que ser explícita.
          */
        private def lastResort(key: Key, base: Currency, quote: Currency): IO[Rate] =
          cache.get.map(_.get(key)).flatMap {
            case Some(e) => IO.pure(e.rate)
            case None => IO.raiseError(ConversionError.RateUnavailable(from = base, to = quote))
          }

        /** Garantiza una sola llamada en vuelo por par de monedas. */
        private def singleFlight(key: Key): IO[Option[Rate]] =
          Deferred[IO, Either[Throwable, Option[Rate]]].flatMap { mine =>
            inFlight
              .modify { m =>
                m.get(key) match
                  case Some(leader) => (m, Left(leader))
                  case None => (m.updated(key, mine), Right(mine))
              }
              .flatMap {
                // Seguidor: espera el resultado del líder. No genera tráfico.
                case Left(leader) =>
                  leader.get.rethrow

                // Líder: llama, publica el resultado y se retira del mapa.
                case Right(deferred) =>
                  fetchGuarded(key).attempt
                    .flatMap { result =>
                      result.toOption.flatten
                        .traverse_(store(key, _)) *>
                        inFlight.update(_ - key) *>
                        deferred.complete(result) *>
                        IO.fromEither(result)
                    }
                    .onCancel {
                      inFlight.update(_ - key) *>
                        deferred.complete(Right(None)).void
                    }
              }
          }

        private def store(key: Key, rate: Rate): IO[Unit] =
          IO.monotonic.flatMap(now => cache.update(_.updated(key, Entry(rate, now))))

        /** Bulkhead + circuit breaker alrededor de la llamada real. */
        private def fetchGuarded(key: Key): IO[Option[Rate]] =
          IO.monotonic.flatMap { now =>
            breaker.get.flatMap {
              case Breaker.Open(until) if now < until =>
                metrics.breakerShortCircuit().as(None)

              case _ =>
                bulkhead.permit
                  .use(_ => api.fetchRate(key.base, key.quote))
                  .flatTap(recordOutcome)
            }
          }

        private def recordOutcome(result: Option[Rate]): IO[Unit] =
          result match
            case Some(_) =>
              breaker.set(Breaker.Closed(0))

            case None =>
              IO.monotonic.flatMap { now =>
                breaker
                  .modify {
                    case Breaker.Closed(failures) if failures + 1 >= config.breakerThreshold =>
                      (Breaker.Open(now + config.breakerResetAfter), true)
                    case Breaker.Closed(failures) =>
                      (Breaker.Closed(failures + 1), false)
                    case Breaker.Open(until) if now >= until =>
                      // Medio abierto: una falla tras la ventana vuelve a abrir.
                      (Breaker.Open(now + config.breakerResetAfter), true)
                    case open =>
                      (open, false)
                  }
                  .flatMap(justOpened => metrics.breakerOpened().whenA(justOpened))
              }
    }
