package co.edu.uco.xebia.bank.observability

import cats.effect.IO
import cats.effect.Resource
import io.prometheus.client.CollectorRegistry
import io.prometheus.client.Counter
import io.prometheus.client.Gauge
import io.prometheus.client.Histogram
import io.prometheus.client.hotspot.DefaultExports

import scala.concurrent.duration.FiniteDuration

/** Instrumentación mínima del sistema bancario.
  *
  * El objetivo NO es medir "todo": es medir las tres cosas que un experimento de
  * caos de rendimiento necesita para poder falsar una hipótesis.
  *
  *   1. Latencia de la operación de negocio (lo que ve el cliente).
  *   2. Latencia de la dependencia externa (lo que causa el daño).
  *   3. Tiempo de espera y de permanencia en la sección crítica (el amplificador).
  *
  * (3) es la métrica que casi nadie instrumenta y es exactamente la que hace
  * visible el problema de esta arquitectura.
  */
trait Metrics:
  def registry: CollectorRegistry

  /** Mide una operación de negocio: `deposit`, `withdraw`, `transfer`. */
  def timeOperation[A](op: String)(fa: IO[A]): IO[A]

  /** Mide una llamada a la dependencia externa de tasas de cambio. */
  def timeUpstream[A](fa: IO[A]): IO[A]

  /** Mide la sección crítica COMPLETA: espera del lock + permanencia. */
  def timeCriticalSection[A](fa: IO[A]): IO[A]

  /** Mide solo la PERMANENCIA dentro del lock (el efecto que corre adentro). */
  def timeLockHold[A](fa: IO[A]): IO[A]

  def cacheHit(): IO[Unit]
  def cacheMiss(): IO[Unit]
  def cacheStale(): IO[Unit]
  def breakerOpened(): IO[Unit]
  def breakerShortCircuit(): IO[Unit]
  def compensationAttempt(): IO[Unit]
  def compensationFailure(): IO[Unit]

object Metrics:

  // Buckets pensados para una dependencia que puede degradarse a segundos.
  // Si tus buckets terminan en 1s, un experimento de caos con 2s de latencia
  // inyectada no te dice nada: todo cae en +Inf.
  private val latencyBuckets: Array[Double] =
    Array(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0)

  def make: Resource[IO, Metrics] =
    Resource.eval(IO {
        val reg = new CollectorRegistry(true)
        // Métricas de JVM (GC, heap, threads). Sin esto no se distingue
        // "la dependencia está lenta" de "estoy en un GC pause".
        DefaultExports.register(reg)

        val opLatency: Histogram =
          Histogram
            .build()
            .name("bank_operation_duration_seconds")
            .help("Duración de una operación de negocio, extremo a extremo.")
            .labelNames("operation", "outcome")
            .buckets(latencyBuckets*)
            .register(reg)

        val opInFlight: Gauge =
          Gauge
            .build()
            .name("bank_operation_in_flight")
            .help("Operaciones de negocio en vuelo. Si sube y no baja, hay encolamiento.")
            .labelNames("operation")
            .register(reg)

        val upstreamLatency: Histogram =
          Histogram
            .build()
            .name("bank_fx_upstream_duration_seconds")
            .help("Duración de la llamada al proveedor de tasas de cambio.")
            .labelNames("outcome")
            .buckets(latencyBuckets*)
            .register(reg)

        val criticalSection: Histogram =
          Histogram
            .build()
            .name("bank_account_critical_section_seconds")
            .help("Sección crítica completa: espera del lock + permanencia dentro.")
            .buckets(latencyBuckets*)
            .register(reg)

        val lockHold: Histogram =
          Histogram
            .build()
            .name("bank_account_lock_hold_seconds")
            .help("Tiempo con el lock de una cuenta tomado. LA metrica del experimento.")
            .buckets(latencyBuckets*)
            .register(reg)

        val cacheEvents: Counter =
          Counter
            .build()
            .name("bank_fx_cache_events_total")
            .help("Eventos del caché de tasas: hit, miss, stale.")
            .labelNames("event")
            .register(reg)

        val breakerEvents: Counter =
          Counter
            .build()
            .name("bank_fx_breaker_events_total")
            .help("Eventos del circuit breaker: opened, short_circuit.")
            .labelNames("event")
            .register(reg)

        val compensation: Counter =
          Counter
            .build()
            .name("bank_transfer_compensation_total")
            .help("Compensaciones de transferencia: attempt, failure.")
            .labelNames("event")
            .register(reg)

        new Metrics:
          override def registry: CollectorRegistry = reg

          private def observe(h: Histogram.Child, d: FiniteDuration): IO[Unit] =
            IO(h.observe(d.toNanos.toDouble / 1e9))

          private def timed[A](fa: IO[A])(record: (FiniteDuration, Boolean) => IO[Unit]): IO[A] =
            IO.monotonic.flatMap { start =>
              fa.guaranteeCase { outcome =>
                IO.monotonic.flatMap { end =>
                  record(end - start, outcome.isSuccess)
                }
              }
            }

          override def timeOperation[A](op: String)(fa: IO[A]): IO[A] =
            IO(opInFlight.labels(op).inc()).bracket { _ =>
              timed(fa) { (elapsed, ok) =>
                observe(opLatency.labels(op, if ok then "success" else "error"), elapsed)
              }
            }(_ => IO(opInFlight.labels(op).dec()))

          override def timeUpstream[A](fa: IO[A]): IO[A] =
            timed(fa) { (elapsed, ok) =>
              observe(upstreamLatency.labels(if ok then "success" else "error"), elapsed)
            }

          override def timeCriticalSection[A](fa: IO[A]): IO[A] =
            timed(fa)((elapsed, _) => observe(criticalSection.labels(), elapsed))

          override def timeLockHold[A](fa: IO[A]): IO[A] =
            timed(fa)((elapsed, _) => observe(lockHold.labels(), elapsed))

          override def cacheHit(): IO[Unit] = IO(cacheEvents.labels("hit").inc())
          override def cacheMiss(): IO[Unit] = IO(cacheEvents.labels("miss").inc())
          override def cacheStale(): IO[Unit] = IO(cacheEvents.labels("stale").inc())
          override def breakerOpened(): IO[Unit] = IO(breakerEvents.labels("opened").inc())
          override def breakerShortCircuit(): IO[Unit] = IO(breakerEvents.labels("short_circuit").inc())
          override def compensationAttempt(): IO[Unit] = IO(compensation.labels("attempt").inc())
          override def compensationFailure(): IO[Unit] = IO(compensation.labels("failure").inc())
    })
