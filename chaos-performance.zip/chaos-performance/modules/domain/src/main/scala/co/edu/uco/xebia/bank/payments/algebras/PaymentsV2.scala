package co.edu.uco.xebia.bank.payments.algebras

import cats.effect.IO
import cats.effect.Outcome
import cats.syntax.all.*

import co.edu.uco.xebia.bank.accounts.models.*
import co.edu.uco.xebia.bank.gateway.RateProvider
import co.edu.uco.xebia.bank.observability.Metrics
import co.edu.uco.xebia.bank.payments.models.*
import co.edu.uco.xebia.bank.persistence.memory.BlockingInMemoryBankPersistence
import co.edu.uco.xebia.bank.shared.*

import scala.util.control.NoStackTrace

/** V2: mismo contrato `Payments`, misma semántica de negocio, distinta forma.
  *
  * ========================= LA IDEA COMPLETA =========================
  *
  * Un lock debe proteger una TRANSICIÓN DE ESTADO, no un PROCEDIMIENTO.
  *
  * V1 mete "resolver la tasa de cambio" dentro del lock porque el cálculo
  * necesita la tasa. Pero la tasa no depende del estado de la cuenta: solo
  * depende del par de monedas. Se puede resolver ANTES.
  *
  * El patrón es leer-calcular-confirmar (optimistic concurrency):
  *
  *   1. LEER      snapshot de la cuenta sin lock (`AtomicCell.get` es lock-free:
  *                en `ConcurrentImpl` está implementado como `ref.get`).
  *   2. CALCULAR  toda la I/O — resolver tasas, convertir — fuera del lock.
  *   3. CONFIRMAR entrar al lock solo para una función PURA: validar la
  *                precondición del snapshot y aplicar el nuevo saldo.
  *
  * El tiempo dentro del lock pasa de "latencia de red de un tercero" a
  * "una suma de BigDecimal". El techo por cuenta pasa de ~2 ops/s a decenas
  * de miles, y —esto es lo importante— DEJA DE DEPENDER de la salud del
  * proveedor de tasas. La latencia del tercero sigue afectando la operación,
  * pero ya no se multiplica por la concurrencia sobre la cuenta.
  *
  * El paso 3 revalida la precondición porque entre (1) y (3) otra fibra pudo
  * cambiar la cuenta. En este dominio la moneda de una cuenta nunca cambia, así
  * que el reintento no se dispara nunca — pero la validación es lo que hace
  * que el patrón sea correcto y no "funciona por casualidad".
  */
object PaymentsV2:

  /** El snapshot dejó de ser válido: hay que recalcular. */
  private case object StaleSnapshot extends RuntimeException("snapshot obsoleto") with NoStackTrace

  private val MaxRetries = 3

  def make(
      rates: RateProvider,
      persistence: BlockingInMemoryBankPersistence,
      metrics: Metrics
  ): Payments =
    new Payments:

      override def deposit(account: AccountId, amount: Money, conversion: ConversionPolicy): IO[Transaction] =
        metrics.timeOperation("deposit") {
          withOptimisticRetry(MaxRetries) {
            for
              snapshot <- readAccount(account)
              currency = snapshot.balance.currency
              // (2) I/O AQUÍ. Sin lock tomado.
              converted <- quote(amount, currency, conversion, account)
              // (3) Sección crítica: pura.
              txId <- commit(account, currency) { balance =>
                Right(add(balance, converted))
              }
            yield Transaction.Deposit(txId, account, amount)
          }
        }

      override def withdraw(account: AccountId, amount: Money, conversion: ConversionPolicy): IO[Transaction] =
        metrics.timeOperation("withdraw") {
          withOptimisticRetry(MaxRetries) {
            for
              snapshot <- readAccount(account)
              currency = snapshot.balance.currency
              converted <- quote(amount, currency, conversion, account)
              // El chequeo de fondos SÍ depende del estado y por eso se hace
              // dentro del lock — pero es una comparación, no una llamada HTTP.
              txId <- commit(account, currency) { balance =>
                subtract(balance, converted).toRight(
                  PaymentError.InsufficientFunds(account, requested = amount, available = balance)
                )
              }
            yield Transaction.Withdrawal(txId, account, amount)
          }
        }

      override def transfer(
          from: AccountId,
          to: AccountId,
          amount: Money,
          conversion: ConversionPolicy
      ): IO[Transaction] =
        metrics.timeOperation("transfer") {
          if from == to then IO.raiseError(PaymentError.SameAccountTransfer(from))
          else
            withOptimisticRetry(MaxRetries) {
              for
                source <- readAccount(from)
                target <- readAccount(to)
                // Ambas conversiones se resuelven ANTES de tocar ningún lock.
                // Además del rendimiento, esto arregla el bug de consistencia
                // de V1: la compensación ya no necesita al proveedor de tasas,
                // porque el monto compensatorio ya está calculado en memoria.
                debit <- quote(amount, source.balance.currency, conversion, from)
                credit <- quote(amount, target.balance.currency, conversion, to)
                _ <- commit(from, source.balance.currency) { balance =>
                  subtract(balance, debit).toRight(
                    PaymentError.InsufficientFunds(from, requested = amount, available = balance)
                  )
                }
                _ <- commit(to, target.balance.currency)(balance => Right(add(balance, credit)))
                  .guaranteeCase {
                    case Outcome.Succeeded(_) => IO.unit
                    case Outcome.Errored(_) | Outcome.Canceled() =>
                      metrics.compensationAttempt() *>
                        commit(from, source.balance.currency)(balance => Right(add(balance, debit))).void
                          .onError { case _ => metrics.compensationFailure() }
                  }
                id <- IO.randomUUID.map(TransactionId.apply)
              yield Transaction.Transfer(id, from, to, amount)
            }
        }

      // ---------------------------------------------------------------------
      // (1) LEER — sin lock
      // ---------------------------------------------------------------------
      private def readAccount(id: AccountId): IO[Account] =
        persistence
          .apply(key = id)
          .get
          .flatMap {
            case Some(account) => IO.pure(account)
            case None => IO.raiseError(PaymentError.AccountDoesNotExist(id))
          }

      // ---------------------------------------------------------------------
      // (2) CALCULAR — toda la I/O vive aquí
      // ---------------------------------------------------------------------
      private def quote(
          amount: Money,
          target: Currency,
          conversion: ConversionPolicy,
          account: AccountId
      ): IO[Money] =
        if amount.currency == target then IO.pure(amount)
        else
          conversion match
            case ConversionPolicy.Reject =>
              IO.raiseError(
                PaymentError.CurrencyMismatch(account, expected = target, actual = amount.currency)
              )
            case ConversionPolicy.Convert =>
              rates.rateFor(base = amount.currency, quote = target).map { rate =>
                Money(MoneyAmount.applyUnsafe(amount.amount * rate), target)
              }

      // ---------------------------------------------------------------------
      // (3) CONFIRMAR — sección crítica puramente CPU-bound
      // ---------------------------------------------------------------------
      private def commit(
          id: AccountId,
          expectedCurrency: Currency
      )(
          f: Money => Either[PaymentError, Money]
      ): IO[TransactionId] =
        metrics
          .timeCriticalSection {
            persistence
              .apply(key = id)
              // Se usa `evalModifyValueIfSet` (y no la variante pura) solo para
              // poder medir `lock_hold` con el MISMO instrumento que V1 y que la
              // comparación del paso 4 sea de manzanas con manzanas. El efecto
              // de adentro es `IO.pure`: no hay I/O, no hay suspensión.
              .evalModifyValueIfSet { account =>
                metrics.timeLockHold {
                  IO.pure {
                    type Outcome = Either[Throwable, Unit]
                    if account.balance.currency != expectedCurrency then
                      account -> (Left(StaleSnapshot): Outcome)
                    else
                      f(account.balance) match
                        case Right(newBalance) =>
                          account.copy(balance = newBalance) -> (Right(()): Outcome)
                        case Left(error) =>
                          account -> (Left(error): Outcome)
                  }
                }
              }
          }
          .flatMap {
            case Some(Right(_)) => IO.randomUUID.map(TransactionId.apply)
            case Some(Left(error)) => IO.raiseError(error)
            case None => IO.raiseError(PaymentError.AccountDoesNotExist(id))
          }

      private def withOptimisticRetry[A](attempts: Int)(fa: IO[A]): IO[A] =
        fa.recoverWith {
          case StaleSnapshot if attempts > 0 => withOptimisticRetry(attempts - 1)(fa)
        }

      private def add(balance: Money, delta: Money): Money =
        Money(MoneyAmount.applyUnsafe(balance.amount + delta.amount), balance.currency)

      private def subtract(balance: Money, delta: Money): Option[Money] =
        Option.when(balance.amount >= delta.amount) {
          Money(MoneyAmount.applyUnsafe(balance.amount - delta.amount), balance.currency)
        }
