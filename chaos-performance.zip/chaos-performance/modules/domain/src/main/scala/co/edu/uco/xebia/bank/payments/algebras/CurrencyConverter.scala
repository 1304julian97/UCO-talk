package co.edu.uco.xebia.bank.payments.algebras

import cats.data.OptionT
import cats.effect.IO
import cats.effect.Resource
import cats.syntax.all.*

import co.edu.uco.xebia.bank.gateway.FrankfurterApi
import co.edu.uco.xebia.bank.payments.models.ConversionError
import co.edu.uco.xebia.bank.persistence.memory.InMemoryCache
import co.edu.uco.xebia.bank.shared.*

import scala.concurrent.duration.FiniteDuration

/** Reemplazo del `CurrencyConverter` original.
  *
  * ÚNICO cambio de comportamiento: `make` ahora RECIBE el `FrankfurterApi` en
  * vez de construirlo. La lógica es idéntica, a propósito — este es el sujeto
  * del experimento, no la solución.
  *
  * El motivo del cambio es metodológico: para inyectar latencia hay que poder
  * sustituir la dependencia sin tocar esta clase. Un componente que construye
  * sus propias dependencias es un componente que no se puede someter a un
  * experimento de caos a nivel de proceso. La inyección de dependencias no es
  * ceremonia: es una precondición de la testabilidad bajo fallo.
  */
trait CurrencyConverter:
  def convert(amount: Money, to: Currency): IO[Money]

object CurrencyConverter:
  def make(api: FrankfurterApi, ttl: FiniteDuration): Resource[IO, CurrencyConverter] =
    InMemoryCache.make[(Currency, Currency), Rate].map { cache =>
      new CurrencyConverter:
        override def convert(amount: Money, to: Currency): IO[Money] =
          val base = amount.currency
          val quote = to

          val cachedRate = OptionT(cache.get(key = base -> quote))
          val apiRate = OptionT(
            api
              .fetchRate(base, quote)
              .flatTap(_.traverse(rate => cache.save(key = base -> quote, value = rate, ttl = ttl)))
          )

          (cachedRate orElse apiRate)
            .getOrRaise(ConversionError.RateUnavailable(from = base, to = quote))
            .map { rate =>
              Money(MoneyAmount.applyUnsafe(amount.amount * rate), to)
            }
    }
