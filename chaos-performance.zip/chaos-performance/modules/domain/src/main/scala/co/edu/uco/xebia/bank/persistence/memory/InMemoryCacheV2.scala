package co.edu.uco.xebia.bank.persistence.memory

import cats.effect.Fiber
import cats.effect.IO
import cats.effect.Ref
import cats.effect.Resource
import cats.effect.std.Supervisor
import cats.syntax.all.*

import scala.concurrent.duration.Duration
import scala.concurrent.duration.FiniteDuration

/** Corrección puntual del caché original.
  *
  * Dos defectos que el experimento de caos amplifica:
  *
  * 1. FUGA DE FIBRAS. `save` hace `supervisor.supervise(unsetKey(key).delayBy(ttl))`
  *    en CADA escritura. Con TTL de 1 hora y una estampida de caché, quedan miles
  *    de fibras dormidas vivas durante una hora. Bajo carga esto se ve como
  *    memoria que sube y no baja — y se confunde con una fuga del dominio.
  *
  * 2. DESALOJO PREMATURO. La fibra de desalojo de una escritura vieja borra el
  *    valor de una escritura nueva. Resultado: fallos de caché aparentemente
  *    aleatorios que reabren el camino lento justo bajo carga.
  *
  * El arreglo: guardar la fibra de desalojo junto al valor y cancelar la anterior
  * al sobrescribir. Aun así, para el caso de las tasas de cambio la respuesta
  * correcta no es este caché sino `RateProvider`, que además hace coalescencia
  * de peticiones y stale-while-revalidate. Este archivo está aquí porque el
  * patrón "cancela el temporizador anterior" vale para cualquier caché con TTL.
  */
object InMemoryCacheV2:

  private final case class Slot[V](value: V, eviction: Fiber[IO, Throwable, Unit])

  def make[K, V]: Resource[IO, InMemoryCache[K, V]] =
    (
      Resource.eval(Ref[IO].of(Map.empty[K, Slot[V]])),
      Supervisor[IO]
    ).mapN { (state, supervisor) =>
      new InMemoryCache[K, V]:

        override def get(key: K): IO[Option[V]] =
          state.get.map(_.get(key).map(_.value))

        override def save(key: K, value: V, ttl: Duration): IO[Unit] =
          ttl match
            case finite: FiniteDuration =>
              supervisor
                .supervise(state.update(_ - key).delayBy(finite))
                .flatMap { eviction =>
                  state
                    .modify { current =>
                      (current.updated(key, Slot(value, eviction)), current.get(key).map(_.eviction))
                    }
                    // Cancelar el desalojo pendiente del valor anterior.
                    .flatMap(_.traverse_(_.cancel))
                }
            case _ =>
              state.update(_ - key)
    }
