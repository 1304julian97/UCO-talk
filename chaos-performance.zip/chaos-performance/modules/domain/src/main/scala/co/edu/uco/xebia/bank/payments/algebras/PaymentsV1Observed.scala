package co.edu.uco.xebia.bank.payments.algebras

import cats.effect.IO
import cats.effect.Outcome

import co.edu.uco.xebia.bank.accounts.models.*
import co.edu.uco.xebia.bank.observability.Metrics
import co.edu.uco.xebia.bank.payments.models.*
import co.edu.uco.xebia.bank.persistence.memory.BlockingInMemoryBankPersistence
import co.edu.uco.xebia.bank.shared.Money

/** V1: la implementación ORIGINAL, sin cambios de comportamiento, solo medida.
  *
  * ================== EL DEFECTO QUE BUSCA EL EXPERIMENTO ==================
  *
  * `persistence(accountId)` devuelve un `AtomicCell[IO, Option[Account]]`, y
  * `AtomicMap` lo construye con un `KeyedMutex`: hay un lock POR CUENTA.
  *
  * `AtomicCell.evalModify` está implementado como `lock.surround { ... f ... }`.
  * Es decir: el efecto que le pasas corre CON EL LOCK TOMADO.
  *
  * El efecto que se le pasa aquí es `calculator.add/subtract`, que con
  * `ConversionPolicy.Convert` y monedas distintas termina en
  * `CurrencyConverter.convert` → `FrankfurterApi.fetchRate` → una llamada HTTP
  * a un tercero por Internet.
  *
  * Conclusión: se hace I/O de red dentro de una sección crítica.
  *
  * El techo de throughput POR CUENTA queda fijado en:
  *
  *     ops/s = 1 / (tiempo dentro del lock)
  *
  * Con la tasa cacheada eso son microsegundos y nadie lo nota. Con 500 ms de
  * latencia inyectada en el proveedor, esa cuenta pasa a soportar 2 ops/s.
  * Y si la llamada falla, el retry del gateway (100+200+400 ms) sostiene el
  * lock ~2.7 s: 0.37 ops/s.
  *
  * Esto NO se ve en pruebas de carga normales, porque en pruebas normales el
  * proveedor responde rápido y el caché está caliente. Se ve inyectando el
  * fallo. De ahí el experimento.
  */
object PaymentsV1Observed:
  def make(
      calculator: MoneyCalculator,
      persistence: BlockingInMemoryBankPersistence,
      metrics: Metrics
  ): Payments =
    new Payments:

      override def deposit(account: AccountId, amount: Money, conversion: ConversionPolicy): IO[Transaction] =
        metrics.timeOperation("deposit") {
          modifyAccountBalance(account) { balance =>
            calculator
              .add(balance, amount, conversion)
              .adaptError { case MoneyError.IncompatibleCurrencies(x, y) =>
                PaymentError.CurrencyMismatch(account, expected = x, actual = y)
              }
          }.map(id => Transaction.Deposit(id, account, amount))
        }

      override def withdraw(account: AccountId, amount: Money, conversion: ConversionPolicy): IO[Transaction] =
        metrics.timeOperation("withdraw") {
          modifyAccountBalance(account) { balance =>
            calculator
              .subtract(balance, amount, conversion)
              .adaptError {
                case MoneyError.IncompatibleCurrencies(x, y) =>
                  PaymentError.CurrencyMismatch(account, expected = x, actual = y)
                case MoneyError.NegativeResult(_, _) =>
                  PaymentError.InsufficientFunds(account, requested = amount, available = balance)
              }
          }.map(id => Transaction.Withdrawal(id, account, amount))
        }

      override def transfer(
          from: AccountId,
          to: AccountId,
          amount: Money,
          conversion: ConversionPolicy
      ): IO[Transaction] =
        metrics.timeOperation("transfer") {
          if from == to then IO.raiseError(PaymentError.SameAccountTransfer(from))
          else
            withdraw(from, amount, conversion) >>
              deposit(to, amount, conversion).guaranteeCase {
                case Outcome.Succeeded(_) => IO.unit
                case Outcome.Errored(_) | Outcome.Canceled() =>
                  // BUG LATENTE, no de rendimiento sino de consistencia:
                  // la compensación vuelve a llamar al proveedor de tasas.
                  // Justo cuando el proveedor está caído (que es cuando esta
                  // rama se ejecuta) la compensación también falla y el dinero
                  // desaparece de la cuenta origen. El experimento de caos lo
                  // hace visible con el contador de compensaciones fallidas.
                  metrics.compensationAttempt() *>
                    deposit(from, amount, conversion).void
                      .onError { case _ => metrics.compensationFailure() }
              } >> IO.randomUUID.map(id => Transaction.Transfer(TransactionId(id), from, to, amount))
        }

      private def modifyAccountBalance(accountId: AccountId)(f: Money => IO[Money]): IO[TransactionId] =
        metrics
          .timeCriticalSection {
            persistence
              .apply(key = accountId)
              .evalModifyValueIfSet { account =>
                // Todo lo que ocurra aquí adentro pasa CON EL LOCK TOMADO.
                metrics.timeLockHold {
                  f(account.balance).map(newBalance => account.copy(balance = newBalance) -> ())
                }
              }
          }
          .flatMap {
            case Some(_) => IO.randomUUID.map(TransactionId.apply)
            case None => IO.raiseError(PaymentError.AccountDoesNotExist(accountId))
          }
