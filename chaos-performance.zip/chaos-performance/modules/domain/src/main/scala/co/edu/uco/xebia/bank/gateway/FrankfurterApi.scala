package co.edu.uco.xebia.bank.gateway

import cats.effect.IO
import cats.effect.Resource
import cats.effect.std.Random
import cats.syntax.all.*
import io.circe.Decoder
import org.http4s.EntityDecoder
import org.http4s.Uri
import org.http4s.circe.CirceEntityDecoder
import org.http4s.client.Client
import org.http4s.ember.client.EmberClientBuilder

import co.edu.uco.xebia.bank.config.FxConfig
import co.edu.uco.xebia.bank.observability.Metrics
import co.edu.uco.xebia.bank.shared.Currency
import co.edu.uco.xebia.bank.shared.Rate

import scala.concurrent.duration.Duration
import scala.concurrent.duration.FiniteDuration
import scala.concurrent.duration.given

trait FrankfurterApi:
  def fetchRate(base: Currency, quote: Currency): IO[Option[Rate]]

object FrankfurterApi:

  private given Uri.Path.SegmentEncoder[Currency] =
    Uri.Path.SegmentEncoder.stringSegmentEncoder.contramap(_.toString)

  private given Decoder[Rate] =
    Decoder[BigDecimal].at(field = "rate").emap(Rate.either)

  private given EntityDecoder[IO, Rate] =
    CirceEntityDecoder.circeEntityDecoder

  private def client(config: FxConfig): Resource[IO, Client[IO]] =
    EmberClientBuilder
      .default[IO]
      // Sin esto, el pool de conexiones es un cuello de botella invisible más.
      .withMaxTotal(256)
      .withTimeout(config.callTimeout)
      .withIdleConnectionTime(30.seconds)
      .build

  // ---------------------------------------------------------------------------
  // V1 — comportamiento ORIGINAL del repositorio, solo que instrumentado.
  //
  // Se conserva a propósito: es el sujeto del experimento. Tres propiedades
  // que el experimento va a explotar:
  //   * no hay timeout de presupuesto total; solo un reintento ciego,
  //   * el backoff no tiene jitter (todos los clientes reintentan a la vez),
  //   * un fallo definitivo devuelve None, que aguas arriba se traduce en
  //     RateUnavailable DESPUÉS de haber consumido ~700 ms + 4 llamadas.
  // ---------------------------------------------------------------------------
  def legacy(config: FxConfig, metrics: Metrics): Resource[IO, FrankfurterApi] =
    client(config).map { http =>
      new FrankfurterApi:
        override def fetchRate(base: Currency, quote: Currency): IO[Option[Rate]] =
          metrics.timeUpstream {
            retry(call(http, config, base, quote))
          }

        private def retry[A](
            operation: IO[A],
            maxRetries: Int = 3,
            delay: Duration = 100.millis
        ): IO[Option[A]] =
          operation.attempt.flatMap {
            case Right(value) => IO.some(value)
            case Left(_) =>
              if maxRetries > 0 then
                IO.sleep(delay) >> retry(operation, maxRetries - 1, delay * 2)
              else IO.none
          }
    }

  // ---------------------------------------------------------------------------
  // V2 — mismo contrato, política de fallo acotada.
  //
  //   * presupuesto TOTAL: pase lo que pase, `fetchRate` termina en `totalBudget`,
  //   * reintentos acotados y con jitter completo,
  //   * el timeout por intento viene del cliente Ember.
  //
  // Esto por sí solo NO arregla el problema de rendimiento: solo acota el daño.
  // El arreglo real está en RateProvider y en PaymentsV2.
  // ---------------------------------------------------------------------------
  def resilient(config: FxConfig, metrics: Metrics): Resource[IO, FrankfurterApi] =
    (client(config), Resource.eval(Random.scalaUtilRandom[IO])).mapN { (http, rnd) =>
      new FrankfurterApi:
        override def fetchRate(base: Currency, quote: Currency): IO[Option[Rate]] =
          metrics.timeUpstream {
            retryWithJitter(call(http, config, base, quote), config.maxRetries, 50.millis)
              .timeoutTo(config.totalBudget, IO.none)
          }

        private def retryWithJitter[A](
            operation: IO[A],
            attemptsLeft: Int,
            base: FiniteDuration
        ): IO[Option[A]] =
          operation.attempt.flatMap {
            case Right(value) => IO.some(value)
            case Left(_) if attemptsLeft > 0 =>
              // Jitter completo: sin esto, N instancias que fallan a la vez
              // reintentan a la vez y rematan a la dependencia que ya está mal.
              rnd.betweenLong(0L, base.toMillis).flatMap { jitterMs =>
                IO.sleep(jitterMs.millis) >>
                  retryWithJitter(operation, attemptsLeft - 1, base * 2)
              }
            case Left(_) => IO.none
          }
    }

  private def call(
      http: Client[IO],
      config: FxConfig,
      base: Currency,
      quote: Currency
  ): IO[Rate] =
    http.get(config.baseUri / base / quote)(_.as[Rate])
