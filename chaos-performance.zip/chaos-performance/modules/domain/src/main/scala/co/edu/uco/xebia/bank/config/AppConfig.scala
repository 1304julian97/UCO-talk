package co.edu.uco.xebia.bank.config

import cats.effect.IO
import org.http4s.Uri

import scala.concurrent.duration.*

/** Modo de ejecución de la ruta de pagos.
  *
  * Poder alternar V1/V2 con una variable de entorno es lo que permite hacer el
  * paso 4 del experimento (repetición) SIN cambiar nada más del entorno:
  * misma imagen, misma infra, mismo generador de carga, mismo fallo inyectado.
  * Si tuvieras que redesplegar código distinto, la comparación deja de ser
  * un experimento controlado y pasa a ser una anécdota.
  */
enum PaymentsImpl:
  case V1 // implementación original: I/O dentro de la sección crítica
  case V2 // implementación corregida: I/O fuera de la sección crítica

final case class FxConfig(
    baseUri: Uri,
    // Presupuesto TOTAL de la llamada, no por intento.
    callTimeout: FiniteDuration,
    totalBudget: FiniteDuration,
    maxRetries: Int,
    // TTL del caché de V1 (el original tiene 1 hora fija en el código).
    //
    // Es configurable por una razón metodológica: con TTL de una hora, en una
    // corrida de 60 segundos hay UNA sola llamada al proveedor por par de
    // monedas. El defecto existe, pero no se manifiesta — y un experimento que
    // no puede manifestar el defecto no demuestra nada.
    //
    // Bajarlo no es hacer trampa: es acelerar el reloj. Lo que en producción
    // pasa una vez por hora (el caché vence y todas las operaciones vuelven a
    // origen a la vez) aquí pasa cada segundo. El fenómeno es el mismo.
    cacheTtl: FiniteDuration,
    // Cuánto tiempo una tasa se considera fresca en V2.
    // DEBE igualar a cacheTtl, o la comparación deja de ser justa: V2 ganaría
    // por tener un caché más largo, no por sacar la I/O de la sección crítica.
    freshFor: FiniteDuration,
    // Cuánto tiempo MÁS se puede seguir sirviendo una tasa vencida
    // mientras se refresca en segundo plano (stale-while-revalidate).
    staleFor: FiniteDuration,
    // Bulkhead: llamadas concurrentes máximas al proveedor.
    maxConcurrentCalls: Int,
    // Circuit breaker.
    breakerThreshold: Int,
    breakerResetAfter: FiniteDuration
)

final case class AppConfig(
    port: Int,
    paymentsImpl: PaymentsImpl,
    fx: FxConfig
)

object AppConfig:

  private def env(key: String): IO[Option[String]] =
    IO(sys.env.get(key).map(_.trim).filter(_.nonEmpty))

  private def envOr[A](key: String, default: A)(parse: String => Option[A]): IO[A] =
    env(key).flatMap {
      case None => IO.pure(default)
      case Some(raw) =>
        IO.fromOption(parse(raw))(
          new IllegalArgumentException(s"valor inválido para $key: $raw")
        )
    }

  val load: IO[AppConfig] =
    for
      port <- envOr("PORT", 8080)(_.toIntOption)
      impl <- envOr("PAYMENTS_IMPL", PaymentsImpl.V1) {
        case s if s.equalsIgnoreCase("v1") => Some(PaymentsImpl.V1)
        case s if s.equalsIgnoreCase("v2") => Some(PaymentsImpl.V2)
        case _ => None
      }
      // Clave para el experimento local: apuntar el gateway a Toxiproxy
      // en vez de al proveedor real.
      fxUri <- envOr("FX_BASE_URI", Uri.unsafeFromString("https://api.frankfurter.dev/v2/rate/"))(
        Uri.fromString(_).toOption
      )
      callTimeout <- envOr("FX_CALL_TIMEOUT_MS", 800.millis)(_.toIntOption.map(_.millis))
      totalBudget <- envOr("FX_TOTAL_BUDGET_MS", 2000.millis)(_.toIntOption.map(_.millis))
      maxRetries <- envOr("FX_MAX_RETRIES", 2)(_.toIntOption)
      cacheTtl <- envOr("FX_CACHE_TTL_MS", 1.hour)(_.toIntOption.map(_.millis))
      freshFor <- envOr("FX_FRESH_MS", 300000)(_.toIntOption).map(_.millis)
      staleFor <- envOr("FX_STALE_FOR_S", 3600.seconds)(_.toIntOption.map(_.seconds))
      maxCalls <- envOr("FX_MAX_CONCURRENT_CALLS", 8)(_.toIntOption)
      threshold <- envOr("FX_BREAKER_THRESHOLD", 5)(_.toIntOption)
      resetAfter <- envOr("FX_BREAKER_RESET_MS", 5000.millis)(_.toIntOption.map(_.millis))
    yield AppConfig(
      port = port,
      paymentsImpl = impl,
      fx = FxConfig(
        baseUri = fxUri,
        callTimeout = callTimeout,
        totalBudget = totalBudget,
        maxRetries = maxRetries,
        cacheTtl = cacheTtl,
        freshFor = freshFor,
        staleFor = staleFor,
        maxConcurrentCalls = maxCalls,
        breakerThreshold = threshold,
        breakerResetAfter = resetAfter
      )
    )
