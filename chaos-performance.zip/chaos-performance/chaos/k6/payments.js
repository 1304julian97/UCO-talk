import http from "k6/http";
import { check, sleep } from "k6";
import { Trend, Rate, Counter } from "k6/metrics";

// ============================================================================
// Generador de carga del experimento.
//
// Dos escenarios que corren EN PARALELO y se comparan entre sí. Esa comparación
// es el corazón del diagnóstico:
//
//   hot     -> todas las operaciones contra UNA cuenta (el comercio).
//   spread  -> operaciones repartidas entre 50 cuentas distintas.
//
// Ambos hacen exactamente el mismo trabajo y llaman al mismo proveedor de
// tasas. Si al inyectar latencia SOLO `hot` se degrada, la latencia del
// proveedor no es la causa raíz: es el disparador. La causa raíz es que hay
// contención sobre una clave. Un solo escenario no permite distinguirlo.
// ============================================================================

const BASE = __ENV.BASE_URL || "http://bank:8080";
const PHASE = __ENV.PHASE || "unknown";
const RATE = Number(__ENV.ARRIVAL_RATE || 60);

const opDuration = new Trend("op_duration", true);
const opFailures = new Rate("op_failures");
const rateUnavailable = new Counter("op_rate_unavailable");

export const options = {
  scenarios: {
    hot: {
      executor: "constant-arrival-rate",
      // Tasa de llegada constante, NO "N usuarios virtuales". Con VUs de bucle
      // cerrado, si el sistema se pone lento el generador manda menos carga y
      // el colapso se oculta. Con llegada constante la carga es independiente
      // de la salud del sistema — que es lo que pasa en producción.
      rate: RATE,
      timeUnit: "1s",
      duration: __ENV.DURATION || "60s",
      preAllocatedVUs: 100,
      maxVUs: 800,
      exec: "hotAccount",
      tags: { scenario: "hot" },
    },
    spread: {
      executor: "constant-arrival-rate",
      rate: RATE,
      timeUnit: "1s",
      duration: __ENV.DURATION || "60s",
      preAllocatedVUs: 100,
      maxVUs: 800,
      exec: "spreadAccounts",
      tags: { scenario: "spread" },
    },
  },

  // ==========================================================================
  // HIPÓTESIS DE ESTADO ESTABLE, escrita como código ejecutable.
  //
  // "Ante una degradación de 500 ms del proveedor de tasas, el servicio de
  //  pagos mantiene p95 < 400 ms, p99 < 1 s y una tasa de fallo < 1 %."
  //
  // Un experimento de caos sin este bloque no es un experimento: es apagar
  // cosas a ver qué pasa. El umbral es lo que hace que el resultado sea
  // FALSABLE y que el paso 4 pueda declarar éxito o fracaso sin discusión.
  // ==========================================================================
  thresholds: {
    "op_duration{scenario:hot}": ["p(95)<400", "p(99)<1000"],
    "op_duration{scenario:spread}": ["p(95)<400", "p(99)<1000"],
    op_failures: ["rate<0.01"],

    // Umbrales triviales cuyo único propósito es que k6 MATERIALICE la
    // submétrica por escenario. Sin ellos, `hot` y `spread` no aparecen por
    // separado en el resumen — y la comparación entre ambos es justamente el
    // paso que distingue "la dependencia está lenta" de "hay contención".
    "iterations{scenario:hot}": ["count>=0"],
    "iterations{scenario:spread}": ["count>=0"],
    "op_failures{scenario:hot}": ["rate>=0"],
    "op_failures{scenario:spread}": ["rate>=0"],
  },

  // Por defecto k6 sólo calcula avg/min/med/max/p(90)/p(95) para las Trends.
  // Si se pide p(99) sin declararlo aquí, sale vacío.
  summaryTrendStats: ["med", "p(95)", "p(99)", "max"],
};

export function setup() {
  // Reintento corto: tras un `docker compose up --force-recreate`, la app puede
  // tardar un instante más de lo que el chequeo del host detectó.
  let res;
  for (let i = 0; i < 30; i++) {
    res = http.get(`${BASE}/seed`);
    if (res.status === 200) break;
    sleep(1);
  }
  if (!res || res.status !== 200) {
    throw new Error(`no se pudo obtener /seed: ${res ? res.status : "sin respuesta"}`);
  }

  const data = res.json();
  console.log(`fase ${PHASE} — implementación activa: ${data.impl}`);
  return data;
}

function money(amount, currency) {
  return { amount, currency };
}

function post(url, body, name) {
  const res = http.post(url, JSON.stringify(body), {
    headers: { "Content-Type": "application/json" },
    tags: { name, phase: PHASE },
  });

  opDuration.add(res.timings.duration, { name });

  // 409 = regla de negocio (fondos insuficientes). No es un fallo del sistema
  // y contarlo como tal falsearía el experimento hacia el lado pesimista.
  const ok = res.status === 200 || res.status === 409;
  opFailures.add(!ok, { name });
  if (res.status === 503) rateUnavailable.add(1);

  check(res, { "no es 5xx": (r) => r.status < 500 });
  return res;
}

// Depósito en EUR sobre una cuenta USD/COP: fuerza conversión de moneda,
// que es el camino que atraviesa la dependencia externa.
export function hotAccount(data) {
  post(
    `${BASE}/account/${data.merchant}/deposit`,
    { amount: money(5, "EUR"), conversion: "Convert" },
    "deposit_hot"
  );
}

export function spreadAccounts(data) {
  const id = data.customers[Math.floor(Math.random() * data.customers.length)];
  post(
    `${BASE}/account/${id}/deposit`,
    { amount: money(5, "EUR"), conversion: "Convert" },
    "deposit_spread"
  );
}

export function handleSummary(data) {
  // /results está montado desde ./results del host (ver docker-compose.yml),
  // así que el resumen sobrevive al contenedor y compare.sh puede leerlo.
  return {
    [`/results/${PHASE}.json`]: JSON.stringify(data, null, 2),
    stdout: summarize(data),
  };
}

function summarize(data) {
  const m = data.metrics;

  const g = (key, stat) =>
    m[key] && m[key].values[stat] !== undefined ? m[key].values[stat] : null;

  const fmt = (v, unit = "") => (v === null ? "    n/a" : v.toFixed(1) + unit);

  // La comparación entre los dos escenarios ES el diagnóstico:
  //   ambos se degradan por igual  -> la dependencia lenta explica todo
  //   solo `hot` se desploma       -> hay contención sobre una clave
  const row = (label, tag) => {
    const d = `op_duration{scenario:${tag}}`;
    const it = `iterations{scenario:${tag}}`;
    const fl = `op_failures{scenario:${tag}}`;
    const rate = g(it, "rate");
    const fail = g(fl, "rate");
    return (
      ` ${label.padEnd(10)}` +
      `${fmt(g(d, "med")).padStart(9)}ms` +
      `${fmt(g(d, "p(95)")).padStart(11)}ms` +
      `${fmt(g(d, "p(99)")).padStart(11)}ms` +
      `${fmt(g(d, "max")).padStart(11)}ms` +
      `${(rate === null ? "n/a" : rate.toFixed(1)).padStart(9)}/s` +
      `${(fail === null ? "n/a" : (fail * 100).toFixed(2)).padStart(8)}%`
    );
  };

  const unavailable = m.op_rate_unavailable
    ? m.op_rate_unavailable.values.count
    : 0;

  return `
==========================================================================================
 FASE: ${PHASE}
------------------------------------------------------------------------------------------
 escenario       p50        p95        p99        max   throughput   fallo
${row("hot", "hot")}
${row("spread", "spread")}
------------------------------------------------------------------------------------------
 total ${
   m.iterations ? m.iterations.values.count : "n/a"
 } iteraciones · ${
   m.iterations ? m.iterations.values.rate.toFixed(1) : "n/a"
 } ops/s · ${unavailable} respuestas 503 (proveedor sin tasa)
==========================================================================================
`;
}
