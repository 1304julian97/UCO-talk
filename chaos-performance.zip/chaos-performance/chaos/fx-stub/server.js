// Doble de prueba del proveedor de tasas (Frankfurter).
//
// Existe por una razón metodológica, no por comodidad: un experimento de caos
// se corre contra una dependencia que TÚ controlas. Inyectarle latencia a la
// API pública de un tercero no es ingeniería del caos, es abuso de un servicio
// ajeno — y además hace el experimento irreproducible, porque su latencia real
// varía y contamina la medición.
//
// Responde el mismo contrato que api.frankfurter.dev/v2/rate/{base}/{quote}.
const http = require("http");

const RATES = {
  "EUR:USD": 1.09, "USD:EUR": 0.92,
  "EUR:COP": 4550.0, "COP:EUR": 0.00022,
  "USD:COP": 4180.0, "COP:USD": 0.00024,
};

// Latencia base del "proveedor sano". La inyección la hace Toxiproxy encima.
const BASE_LATENCY_MS = Number(process.env.BASE_LATENCY_MS || 20);

http
  .createServer((req, res) => {
    const parts = req.url.split("?")[0].split("/").filter(Boolean);
    const [base, quote] = parts.slice(-2);
    const rate = RATES[`${base}:${quote}`];

    setTimeout(() => {
      if (!rate) {
        res.writeHead(404, { "content-type": "application/json" });
        res.end(JSON.stringify({ error: "unknown pair" }));
        return;
      }
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ base, quote, rate }));
    }, BASE_LATENCY_MS);
  })
  .listen(3000, () => console.log("[fx-stub] :3000, latencia base " + BASE_LATENCY_MS + "ms"));
