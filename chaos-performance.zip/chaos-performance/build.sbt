// build.sbt — reemplaza el del repositorio.
// Cambios respecto al original marcados con [CAOS].

ThisBuild / scalaVersion := "3.8.4"
ThisBuild / organization := "co.edu.uco"

val catsVersion = "2.13.0"
val catsEffectVersion = "3.7.0"
val circeVersion = "0.14.16"
val fs2Version = "3.13.0"
val http4sVersion = "0.23.34"
val ironVersion = "3.3.2"
// [CAOS] Cliente Prometheus. Coordenadas estables y sin dependencias
// transitivas problemáticas; se expone /metrics a mano en OpsRoutes.
val prometheusVersion = "0.16.0"

lazy val commonSettings = Seq(
  scalacOptions += "-Wconf:any:verbose,id=E198:silent",
  libraryDependencies ++= Seq(
    "org.typelevel" %% "cats-core"   % catsVersion,
    "org.typelevel" %% "cats-effect" % catsEffectVersion,
    "co.fs2"        %% "fs2-core"    % fs2Version,
    "co.fs2"        %% "fs2-io"      % fs2Version
  )
)

lazy val domain =
  project
    .in(file("modules/domain"))
    .settings(commonSettings)
    .settings(
      libraryDependencies ++= Seq(
        "io.circe"           %% "circe-core"          % circeVersion,
        "org.http4s"         %% "http4s-circe"        % http4sVersion,
        "org.http4s"         %% "http4s-client"       % http4sVersion,
        "org.http4s"         %% "http4s-ember-client" % http4sVersion,
        "io.github.iltotore" %% "iron"                % ironVersion,
        // [CAOS] métricas
        "io.prometheus"       % "simpleclient"         % prometheusVersion,
        "io.prometheus"       % "simpleclient_common"  % prometheusVersion,
        "io.prometheus"       % "simpleclient_hotspot" % prometheusVersion
      )
    )

lazy val server =
  project
    .in(file("modules/server"))
    .dependsOn(domain)
    .settings(commonSettings)
    .settings(
      run / fork := true,
      libraryDependencies ++= Seq(
        "org.http4s" %% "http4s-server"       % http4sVersion,
        "org.http4s" %% "http4s-ember-server" % http4sVersion,
        "org.http4s" %% "http4s-dsl"          % http4sVersion,
        "org.http4s" %% "http4s-circe"        % http4sVersion,
        "io.circe"   %% "circe-core"          % circeVersion,
        "io.circe"   %% "circe-generic"       % circeVersion,
        "io.circe"   %% "circe-parser"        % circeVersion,
        // [CAOS] OpsRoutes expone /metrics con TextFormat. Llegaría igual de
        // forma transitiva desde `domain`, pero declararlo donde se usa evita
        // que un cambio en domain rompa el server sin razón aparente.
        "io.prometheus" % "simpleclient"        % prometheusVersion,
        "io.prometheus" % "simpleclient_common" % prometheusVersion
      )
    )
    // [CAOS] `sbt server/stage` produce un árbol ejecutable en
    // modules/server/target/universal/stage/ que el Dockerfile copia a la
    // imagen final. No hace falta DockerPlugin: la imagen la construye el
    // Dockerfile multi-etapa, que es lo que permite compilar sin JDK ni sbt
    // instalados en la máquina que presenta.
    .enablePlugins(JavaAppPackaging)

lazy val root =
  project
    .in(file("."))
    .aggregate(domain, server)

addCommandAlias("validate", "scalafmtCheckAll; compile; test")
