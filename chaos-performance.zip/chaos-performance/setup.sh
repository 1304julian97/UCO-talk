#!/usr/bin/env bash
# =============================================================================
#  Puesta en marcha — ejecutar UNA sola vez, antes que nada.
#
#  El problema que resuelve: esta carpeta trae SOLO los archivos nuevos y los
#  modificados. Los fuentes originales del repositorio (Accounts, el trait
#  Payments, los tipos de `shared`, la persistencia con AtomicMap, las rutas de
#  cuentas) no están aquí y hacen falta para compilar.
#
#  Este script trae esos fuentes y los deja junto a los nuestros, SIN pisar
#  ninguno de los nuestros. Después de correrlo, la carpeta es autosuficiente y
#  `./run.sh up` funciona.
#
#  Uso:
#    ./setup.sh                      clona el repo desde GitHub
#    ./setup.sh /ruta/a/UCO-talk     usa un clon que ya tengas en disco
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")"

REPO_URL="https://github.com/1304julian97/UCO-talk.git"
SRC="${1:-}"
TMP=".repo-src"

log()  { printf '\n\033[1;36m▶ %s\033[0m\n' "$*"; }
note() { printf '  \033[2m%s\033[0m\n' "$*"; }
fail() { printf '\n\033[1;31m✕ %s\033[0m\n' "$*"; exit 1; }

# --- 0. comprobar que el árbol de la entrega está completo --------------------
# Si descargaste los archivos sueltos desde el chat, quedan planos en una
# carpeta y se pierde la estructura de directorios. Sin ella nada funciona,
# y conviene decirlo acá y no tres pasos más adelante.
own=""
for f in build.sbt project/plugins.sbt Dockerfile docker-compose.yml \
         chaos/k6/payments.js chaos/observability/prometheus.yml \
         modules/domain/src/main/scala/co/edu/uco/xebia/bank/payments/algebras/PaymentsV2.scala; do
  [ -e "$f" ] || own="$own\n    $f"
done

if [ -n "$own" ]; then
  printf '\n\033[1;31m✕ Esta carpeta no tiene el árbol completo de la entrega.\033[0m\n'
  printf '  Estás en: %s\n' "$PWD"
  printf '  Falta:%b\n\n' "$own"
  printf '  Casi seguro descargaste los archivos sueltos desde el chat: quedan\n'
  printf '  planos en una carpeta y se pierde la estructura de directorios.\n\n'
  printf '  Descargá el \033[1mchaos-uco.zip\033[0m, descomprimilo y trabajá dentro de\n'
  printf '  la carpeta chaos-performance/ que crea:\n\n'
  printf '      unzip chaos-uco.zip\n'
  printf '      cd chaos-performance\n'
  printf '      ./setup.sh\n\n'
  exit 1
fi

# --- 1. conseguir los fuentes originales -------------------------------------
if [ -n "$SRC" ]; then
  [ -d "$SRC/modules" ] || fail "en $SRC no hay un directorio modules/ — ¿es el clon de UCO-talk?"
  log "usando el clon local: $SRC"
else
  command -v git >/dev/null || fail "hace falta git, o pasá la ruta de un clon: ./setup.sh /ruta/a/UCO-talk"
  log "clonando $REPO_URL"
  rm -rf "$TMP"
  git clone --depth 1 "$REPO_URL" "$TMP" >/dev/null 2>&1 \
    || fail "no se pudo clonar. Si estás sin red, cloná aparte y pasá la ruta: ./setup.sh /ruta/a/UCO-talk"
  SRC="$TMP"
  note "clonado en $TMP"
fi

# --- 2. copiar solo lo que falta ---------------------------------------------
# La regla es «no sobrescribir»: si el archivo ya existe aquí, es porque es
# nuestra versión instrumentada y debe ganar. Concretamente Main.scala y
# CurrencyConverter.scala viven en la misma ruta que los originales.
log "trayendo los fuentes originales que no reemplazamos"

copied=0
kept=0
while IFS= read -r -d '' f; do
  if [ -e "./$f" ]; then
    kept=$((kept + 1))
  else
    mkdir -p "./$(dirname "$f")"
    cp "$SRC/$f" "./$f"
    copied=$((copied + 1))
  fi
done < <(cd "$SRC" && find modules -type f -print0)

note "$copied archivos traídos del repo"
note "$kept archivos conservados (nuestra versión instrumentada)"

# .scalafmt.conf: el Dockerfile lo copia si existe, y `sbt validate` lo pide.
if [ -f "$SRC/.scalafmt.conf" ] && [ ! -f ".scalafmt.conf" ]; then
  cp "$SRC/.scalafmt.conf" .
  note ".scalafmt.conf traído"
fi

rm -rf "$TMP"

# --- 3. verificar que quedó compilable ---------------------------------------
log "verificando"
missing=""
for f in build.sbt project/build.properties project/plugins.sbt Dockerfile docker-compose.yml \
         modules/domain/src/main/scala/co/edu/uco/xebia/bank/payments/algebras/Payments.scala \
         modules/domain/src/main/scala/co/edu/uco/xebia/bank/payments/algebras/PaymentsV2.scala \
         modules/server/src/main/scala/co/edu/uco/xebia/bank/Main.scala \
         chaos/k6/payments.js chaos/observability/prometheus.yml; do
  [ -e "$f" ] || missing="$missing\n    $f"
done

if [ -n "$missing" ]; then
  printf '\033[1;31m✕ faltan archivos:%b\033[0m\n' "$missing"
  exit 1
fi

printf '  \033[1;32mtodo en su lugar\033[0m\n'
cat <<'TXT'

Siguiente paso:

    ./run.sh up      levanta el laboratorio (la primera vez compila: 3-6 min)
    ./run.sh all     las cuatro fases del experimento
    ./run.sh demo    solo las fases 2 y 4 — el camino para la charla
TXT
