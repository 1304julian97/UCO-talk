#!/usr/bin/env bash
# =============================================================================
#  Comparación de las fases del experimento.
#
#  Dos fuentes, a propósito:
#
#    k6          lo que vio el CLIENTE (latencia, throughput, fallos).
#    Prometheus  lo que pasó ADENTRO (lock, dependencia, cola).
#
#  La primera dice si la hipótesis se sostuvo. La segunda dice por qué.
#  Con una sola de las dos, el experimento no concluye nada accionable.
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")"

RESULTS="${RESULTS:-results}"
PROM="${PROM:-http://localhost:9090}"
PHASES="1-baseline-v1 2-chaos-v1 3-baseline-v2 4-chaos-v2"

command -v jq >/dev/null || { echo "hace falta jq (brew install jq / apt install jq)"; exit 1; }

bar() { printf '%.0s─' $(seq 1 "$1"); printf '\n'; }

# -----------------------------------------------------------------------------
# 1. Lo que vio el cliente
# -----------------------------------------------------------------------------
printf '\n\033[1mLO QUE VIO EL CLIENTE  (k6)\033[0m\n'
bar 84
printf '%-16s %-8s %9s %9s %9s %10s %9s\n' FASE ESCENARIO p50 p95 p99 "ops/s" "fallo %"
bar 84

for phase in $PHASES; do
  f="$RESULTS/$phase.json"
  if [ ! -f "$f" ]; then
    printf '%-16s %9s\n' "$phase" "—"
    continue
  fi
  for sc in hot spread; do
    jq -r --arg p "$phase" --arg sc "$sc" '
      .metrics as $m |
      def r(x): (x // 0) * 10 | round / 10 | tostring;
      ($m["op_duration{scenario:" + $sc + "}"].values // {}) as $d |
      ($m["iterations{scenario:" + $sc + "}"].values // {}) as $i |
      ($m["op_failures{scenario:" + $sc + "}"].values // {}) as $e |
      [ $p, $sc, r($d.med), r($d["p(95)"]), r($d["p(99)"]),
        r($i.rate), r(($e.rate // 0) * 100) ] | @tsv' "$f" |
    awk -F'\t' '{printf "%-16s %-8s %9s %9s %9s %10s %9s\n", $1, $2, $3, $4, $5, $6, $7}'
  done
done

# -----------------------------------------------------------------------------
# 2. Lo que pasó adentro
# -----------------------------------------------------------------------------
if [ ! -f "$RESULTS/phases.txt" ] || ! curl -sf "$PROM/-/healthy" >/dev/null 2>&1; then
  printf '\n(sin datos internos: Prometheus no responde o falta results/phases.txt)\n'
else
  printf '\n\033[1mLO QUE PASÓ ADENTRO  (Prometheus, p99 de cada ventana)\033[0m\n'
  bar 84
  printf '%-16s %13s %13s %13s %10s\n' FASE "permanencia" "sec.crítica" "proveedor" "razón"
  bar 84

  # Consulta el p99 promedio de una métrica durante la ventana exacta de la fase.
  # `query_range` y no `query`: interesa la fase, no el instante actual.
  prom_p99() {
    local metric="$1" start="$2" end="$3"
    curl -sfg "$PROM/api/v1/query_range" \
      --data-urlencode "query=histogram_quantile(0.99, sum by (le) (rate(${metric}_bucket[30s])))" \
      --data-urlencode "start=$start" --data-urlencode "end=$end" --data-urlencode "step=10" \
      2>/dev/null |
      jq -r '[.data.result[0].values[]?[1] | tonumber | select(. == .)] | if length > 0 then (add/length) else 0 end' \
      2>/dev/null || echo 0
  }

  # Blindaje: cualquier camino que devuelva vacío se normaliza a 0.
  num() { local v="$1"; case "$v" in ''|*[!0-9.eE+-]*) echo 0 ;; *) echo "$v" ;; esac; }

  while read -r phase start end; do
    hold=$(num "$(prom_p99 bank_account_lock_hold_seconds "$start" "$end")")
    crit=$(num "$(prom_p99 bank_account_critical_section_seconds "$start" "$end")")
    up=$(num "$(prom_p99   bank_fx_upstream_duration_seconds "$start" "$end")")
    awk -v p="$phase" -v h="$hold" -v c="$crit" -v u="$up" '
      BEGIN {
        # El +0 fuerza contexto numérico. Sin él, una consulta vacía llega como
        # cadena "" y `"" > 0.001` se evalúa como comparación de cadenas —
        # resulta verdadera y el script termina dividiendo por cero.
        hn = h + 0; cn = c + 0; un = u + 0
        ratio = (un > 0.001) ? hn / un : 0
        printf "%-16s %12.3fs %12.3fs %12.3fs %9.2f\n", p, hn, cn, un, ratio
      }'
  done < "$RESULTS/phases.txt"
fi

cat <<'TXT'

Cómo leer las dos tablas
────────────────────────
  1 vs 2   El tamaño del daño. Si el p99 sube MUCHO más que los 500 ms
           inyectados, la diferencia es AMPLIFICACIÓN: cola detrás de un lock,
           no la latencia del tercero.

  1 vs 3   Que v2 no haya empeorado el caso sano. Si 3 es peor que 1, la
           "solución" cambió un problema por otro.

  2 vs 4   El resultado del experimento. Es el único par que responde la
           pregunta que se hizo al principio.

Y la comparación entre los DOS escenarios de la primera tabla:

  hot y spread se degradan igual   → la dependencia lenta explica todo
  solo hot se desploma             → hay contención sobre una clave

La columna `razón` (permanencia ÷ proveedor) es el diagnóstico:

  razón ≈ 1     hay I/O de red DENTRO de la sección crítica
  razón ≈ 0     el lock solo envuelve cálculo, como debe ser

  sec.crítica ≫ permanencia   → hay cola esperando el lock
  sec.crítica ≈ permanencia   → no hay contención

Esa relación entre dos histogramas es la diferencia entre "el sistema está
lento" y "sé exactamente qué línea de código hay que mover".
TXT
