# Experimento de Ingeniería del Caos — rendimiento
### Sobre `1304julian97/UCO-talk` (Scala 3 · Cats Effect · http4s)
**Todo local. Única dependencia de la máquina: Docker.**

---

## Puesta en marcha (una sola vez)

```bash
./setup.sh        # trae los fuentes originales del repositorio
./run.sh up       # compila dentro de Docker y levanta las seis piezas
```

**`setup.sh` no es opcional.** Esta carpeta contiene solo los archivos nuevos y
los modificados: los fuentes originales (`Accounts`, el trait `Payments`, los
tipos de `shared`, la persistencia con `AtomicMap`, las rutas de cuentas) no
están aquí y hacen falta para compilar. `setup.sh` los clona y los deja junto a
los nuestros **sin pisar ninguno de los nuestros** — importa porque `Main.scala`
y `CurrencyConverter.scala` viven en la misma ruta que sus originales.

Si ya tenés el repositorio clonado: `./setup.sh /ruta/a/UCO-talk`.

Si `docker compose` falla con `failed to compute cache key: "/modules": not
found`, es exactamente esto: el contexto de build no tiene el proyecto Scala.
`run.sh` lo detecta antes y lo dice con todas las letras.

Después de eso, todo el experimento corre en segundos.

| | |
|---|---|
| App | http://localhost:8080 |
| **Grafana** | **http://localhost:3000** — tablero ya cargado, sin login |
| Prometheus | http://localhost:9090/alerts |
| Toxiproxy | http://localhost:8474 |

Correr las cuatro fases **antes** de subir al escenario y dejar los JSON en
`results/`. Si el wifi del auditorio falla, `./compare.sh` cuenta la historia
completa sin red.

```bash
./run.sh all       # las cuatro fases, ~7 min
./run.sh demo      # solo fases 2 y 4, ~4 min — el camino para la charla
```

---

## Resumen de la revisión del repositorio

El repo es un modelo de dominio bancario con álgebras (`Accounts`, `Payments`,
`MoneyCalculator`, `CurrencyConverter`), tipos refinados con Iron, persistencia
en memoria y un servidor http4s Ember. Está bien tipado y bien organizado.

Tiene un defecto de rendimiento que **ninguna prueba de carga convencional
encuentra**, y que un experimento de caos encuentra en sesenta segundos. Eso lo
hace un sujeto casi ideal para la charla: el código no es "malo", es plausible.
Es el tipo de código que pasa una revisión.

### El defecto

`BlockingInMemoryBankPersistence` es un `AtomicMap[IO, AccountId, Option[Account]]`.
`AtomicMap` se construye con un `KeyedMutex`: **hay un lock por cuenta**. Y
`AtomicCell.evalModify` está implementado, literalmente, como:

```scala
override def evalModify[B](f: A => F[(A, B)]): F[B] =
  lock.surround {
    ref.get.flatMap(f).flatMap { case (a, b) => ref.set(a).as(b) }
  }
```

El efecto que se le pasa **corre con el lock tomado**.

Ahora, la cadena de llamadas en `Payments.modifyAccountBalance`:

```
Payments.deposit
  └─ persistence(accountId).evalModifyValueIfSet {   ← lock de la cuenta TOMADO
       calculator.add(balance, amount, Convert)
         └─ CurrencyConverter.convert
              └─ FrankfurterApi.fetchRate
                   └─ client.get(api.frankfurter.dev)  ← petición HTTP por Internet
     }                                                  ← lock LIBERADO
```

**Se hace I/O de red dentro de una sección crítica.** El techo de throughput por
cuenta queda fijado en `1 / (tiempo dentro del lock)`:

| Situación | Tiempo en el lock | Techo por cuenta |
|---|---|---|
| Tasa en caché | ~µs | decenas de miles op/s |
| Caché fría, proveedor sano (~30 ms) | 30 ms | ~33 op/s |
| Proveedor degradado a 500 ms | 500 ms | **2 op/s** |
| Proveedor con fallos (retry 100+200+400 ms sin timeout) | ~2.7 s | **0.37 op/s** |

Con `-Xmx512m` y llegadas constantes, esa cuenta no se pone "lenta": se convierte
en una cola sin fin y el heap sube hasta que el proceso muere.

### Hallazgos secundarios (todos los revela el mismo experimento)

1. **Sin timeout de presupuesto.** `FrankfurterApi.retry` reintenta 3 veces sin
   límite de tiempo total. Un proveedor colgado sostiene el lock indefinidamente.
2. **Reintentos sin jitter.** `100→200→400 ms` fijos: todos los clientes
   reintentan a la vez y rematan a la dependencia que ya está mal.
3. **Estampida de caché.** `InMemoryCache` se escribe solo tras un éxito y no
   hace coalescencia. N peticiones concurrentes con caché fría → N llamadas.
4. **TTL duro.** Al vencer la hora, todas las peticiones vuelven a origen a la
   vez: acantilado de latencia periódico.
5. **Fuga de fibras.** `save` hace `supervisor.supervise(unsetKey.delayBy(1.hour))`
   en cada escritura. Bajo estampida quedan miles de fibras dormidas una hora. Y
   la fibra vieja desaloja el valor nuevo.
6. **Pérdida de dinero.** En `transfer`, la compensación (`deposit` de vuelta al
   origen) **vuelve a llamar al proveedor de tasas** — justo cuando el proveedor
   está caído, que es cuando esa rama se ejecuta. Si falla, el dinero sale de la
   cuenta origen y no llega a ninguna parte. Este no es un bug de rendimiento;
   es de consistencia. Lo encontró el experimento de rendimiento. Suele pasar.

> `Main.runServer` usa `.allocated.map(_._1)`, que descarta el finalizador del
> servidor, y construye un `DummyAccountImpl` que nunca se usa. Menor, pero
> conviene arreglarlo antes: alguien lo va a ver en pantalla.

---

## Estructura

Todo el árbol se copia **sobre la raíz del repo**:

```
Dockerfile              compila el proyecto dentro de Docker (sin JDK ni sbt local)
docker-compose.yml      las seis piezas del laboratorio
run.sh                  el experimento completo
compare.sh              comparación de las fases (k6 + Prometheus)

build.sbt               ← reemplaza el original (añade métricas y `stage`)
project/plugins.sbt     ← reemplaza el original
modules/…               instrumentación, rutas HTTP y la solución

chaos/
  fx-stub/              doble del proveedor de tasas
  toxiproxy/            configuración del inyector de fallos
  k6/                   generador de carga + hipótesis como umbrales
  observability/        Prometheus, reglas de alerta y Grafana aprovisionado

ci/chaos-gate.yml       el experimento como control de regresión en cada PR
```

De los archivos existentes solo se **reemplazan** tres: `build.sbt`,
`project/plugins.sbt` y `CurrencyConverter.scala` (este último únicamente para
recibir el `FrankfurterApi` por parámetro en vez de construirlo — sin eso no se
puede sustituir la dependencia para el experimento).

**No se pudieron compilar aquí** (el entorno donde se generaron no alcanza Maven
Central). El primer `./run.sh up` compila de verdad; si algo no cuadra, sale ahí.

---

## 1. Cómo encontrar el problema de rendimiento

### La hipótesis, primero

Un experimento de caos empieza por escribir qué se espera que pase. Si no, no es
un experimento: es apagar cosas a ver qué sale.

> **Estado estable:** ante una degradación de 500 ms en el proveedor de tasas de
> cambio, el servicio de pagos mantiene p95 < 400 ms, p99 < 1 s y una tasa de
> fallo inferior al 1 %.

Está codificada en `chaos/k6/payments.js` como `thresholds`. Eso la vuelve
falsable sin discusión: k6 sale con código 99 si no se cumple.

### Las dos decisiones de diseño que hacen que el experimento funcione

**Llegada constante, no usuarios virtuales.** Con VUs en bucle cerrado, si el
sistema se pone lento el generador manda menos carga y el colapso se esconde. Con
`constant-arrival-rate` la carga es independiente de la salud del sistema — como
en producción.

**Dos escenarios en paralelo: `hot` y `spread`.** Ambos hacen el mismo trabajo y
llaman al mismo proveedor. `hot` va todo contra una cuenta (el comercio);
`spread` reparte entre cincuenta. Si al inyectar latencia **solo `hot` se
degrada**, la latencia del proveedor no es la causa raíz: es el disparador. La
causa raíz es contención sobre una clave. Con un solo escenario no se puede
distinguir, y se termina "arreglando" la dependencia equivocada.

### Acelerar el reloj (y decirlo en voz alta)

El código original cachea las tasas **una hora**. En una corrida de 60 segundos
eso significa una sola llamada al proveedor por par de monedas: el defecto está
ahí, pero no alcanza a manifestarse — de hecho, la primera vez que corrí el
experimento, la fase 2 salió idéntica a la línea base.

Por eso `FX_CACHE_TTL_MS` está en **1 segundo**. Lo que en producción ocurre una
vez por hora —el caché vence y todas las operaciones vuelven a origen a la vez—
aquí ocurre sesenta veces. El fenómeno es el mismo, sólo más seguido.

Y `FX_FRESH_MS` (el horizonte de frescura de v2) vale **lo mismo**, a propósito.
Si v2 cacheara más tiempo que v1 ganaría por eso, no por sacar la I/O de la
sección crítica, y la comparación dejaría de demostrar lo que dice demostrar.
Si alguien en el público pregunta por esto, es la pregunta correcta.

> Segundo experimento, si sobra tiempo: poner `FX_STALE_FOR_S: "0"`. Eso quita
> el stale-while-revalidate y deja a v2 yendo a origen tan seguido como v1. El
> p99 sube en ambos, pero la **cola** sigue existiendo sólo en v1. Aísla el
> efecto del lock del efecto del caché.

### La inyección de fallo

Toxiproxy se pone entre la app y el doble del proveedor. La toxina se activa y se
quita con un `curl`, en un segundo, delante del público:

```bash
./run.sh latency on     # +500 ms hacia el proveedor de tasas
./run.sh latency off
```

Nunca contra la API pública real: eso no es ingeniería del caos, es abusar de un
servicio ajeno, y además hace la medición irreproducible.

### Lo que se observa

Fase 1 (sano) pasa los umbrales. Fase 2 (+500 ms):

- `hot` se desploma: p99 a decenas de segundos, throughput a ~2 op/s.
- `spread` se degrada de forma proporcional y benigna.
- El resumen de k6 y `compare.sh` muestran las dos filas **por separado**: esa
  diferencia entre escenarios es el diagnóstico, no un detalle de presentación.
- `bank_operation_in_flight` sube y **no baja**.
- El heap sube y no vuelve.
- `bank_account_lock_hold_seconds` ≈ `bank_fx_upstream_duration_seconds`.

Esa última igualdad **es el diagnóstico**, y está como tarjeta grande en el
tablero (`permanencia ÷ latencia del proveedor`). Es la línea que separa "el
sistema está lento" de "sé exactamente qué línea de código hay que mover".

---

## 2. Cómo monitorearlo

Prometheus + Grafana, **aprovisionados de fábrica**: el datasource y el tablero
ya están cargados al levantar el compose. Nadie quiere ver a alguien importando
un JSON en vivo, y son dos minutos de treinta.

### El tablero va de síntoma a causa, de arriba abajo

http://localhost:3000

```
tarjetas        SLO p99 · permanencia ÷ proveedor · operaciones en vuelo
1  SÍNTOMA      latencia p50/p95/p99 · throughput y errores
2  AMPLIFICADOR sección crítica vs. permanencia en el lock · trabajo en vuelo
3  CAUSA        latencia del proveedor · caché, breaker y compensaciones
4  JVM          heap · GC e hilos
```

Es el recorrido que hace quien está de guardia a las 3 a. m. También es el guion
de la demo. El panel 4 existe para descartar en vivo la explicación alternativa
más común: *"no está lento por el lock, está en una pausa de GC"*.

### Hacerlo local no es una concesión: para esto es mejor

Prometheus guarda los **histogramas completos**, así que `histogram_quantile` da
percentiles de verdad. Los servicios gestionados de métricas suelen aplanar los
buckets a suma/conteo/máximo, y ahí se pierde justo lo que este experimento
necesita medir. Además, el ciclo *inyectar → ver → quitar* es de un segundo, no
de un despliegue.

### Alertas que dicen qué hacer, no solo que algo pasa

En `chaos/observability/alert-rules.yml` (visibles en
http://localhost:9090/alerts):

| Alerta | Tipo | Qué dice |
|---|---|---|
| `SLOBreach` | síntoma | El p99 rompió el SLO. Se dispara tarde. |
| `IoInsideLock` | **causa raíz** | La permanencia en el lock sigue a la latencia del proveedor: hay I/O de red dentro de la sección crítica. |
| `LockContention` | amplificador | Se espera por el lock mucho más de lo que se permanece dentro. Hay cola. |
| `WorkPilingUp` | amplificador | Trabajo aceptado que no termina. Sin backpressure, termina en OOM. |

Una alerta que solo dice "el p99 subió" obliga a alguien a investigar de
madrugada. `IoInsideLock` le dice qué archivo abrir. Esa diferencia es, en sí
misma, un buen punto para la charla.

---

## 3. Cómo resolverlo

### El principio

> Un lock protege una **transición de estado**, no un **procedimiento**.

La tasa de cambio no depende del estado de la cuenta: solo del par de monedas.
Se puede resolver antes de tomar el lock. El patrón es **leer → calcular →
confirmar**:

```scala
// (1) LEER — sin lock. AtomicCell.get es ref.get, no toca el mutex.
snapshot  <- readAccount(account)

// (2) CALCULAR — toda la I/O vive aquí, fuera de la sección crítica.
converted <- quote(amount, snapshot.balance.currency, conversion, account)

// (3) CONFIRMAR — el lock solo envuelve una función pura.
txId      <- commit(account, snapshot.balance.currency) { balance =>
               Right(add(balance, converted))
             }
```

`commit` revalida la precondición del snapshot antes de aplicar (concurrencia
optimista). En este dominio la moneda de una cuenta nunca cambia, así que el
reintento no se dispara nunca — pero la validación es lo que hace que el patrón
sea correcto y no "funciona por casualidad".

El tiempo dentro del lock pasa de *latencia de red de un tercero* a *una suma de
`BigDecimal`*. La latencia del proveedor sigue afectando la operación, pero **ya
no se multiplica por la concurrencia sobre la cuenta**.

→ `modules/domain/src/main/scala/co/edu/uco/xebia/bank/payments/algebras/PaymentsV2.scala`

### Lo que acompaña, en orden de impacto

| Patrón | Hallazgo que resuelve | Dónde |
|---|---|---|
| I/O fuera del lock | El defecto principal | `PaymentsV2.scala` |
| Single-flight | Estampida de caché (N llamadas → 1) | `RateProvider.scala` |
| Stale-while-revalidate | Acantilado periódico por TTL duro | `RateProvider.scala` |
| Circuit breaker | Pagar el presupuesto completo con el proveedor caído | `RateProvider.scala` |
| Bulkhead (semáforo) | Concurrencia ilimitada hacia el proveedor | `RateProvider.scala` |
| Presupuesto total + jitter | Retry sin cota y en manada | `FrankfurterApi.resilient` |
| Cancelar desalojo anterior | Fuga de fibras y desalojo prematuro | `InMemoryCacheV2.scala` |
| Conversión previa a los locks | La compensación ya no llama al proveedor | `PaymentsV2.transfer` |

Sobre stale-while-revalidate hay una decisión de negocio escondida: servir una
tasa de hace seis minutos es un problema aceptable; tener 3 s de p99 no lo es.
Si en tu dominio no es aceptable, se borra esa rama y se falla. Lo importante es
que la decisión sea **explícita** y no un efecto secundario del TTL.

---

## 4. Repetición de la prueba

La clave metodológica: **la única variable que cambia es `PAYMENTS_IMPL`**. Misma
imagen, mismo compose, mismo generador, mismo fallo inyectado. Si hubiera que
reconstruir una imagen distinta, la comparación dejaría de ser un experimento
controlado y pasaría a ser una anécdota.

```
1-baseline-v1   v1, proveedor sano   → se establece el estado estable
2-chaos-v1      v1, +500 ms          → se falsa la hipótesis (el hallazgo)
3-baseline-v2   v2, proveedor sano   → se verifica que no hubo regresión
4-chaos-v2      v2, +500 ms          → se evidencia la solución
```

**La fase 3 es la que casi todo el mundo omite**, y es la que evita el error
clásico: arreglar el caso degradado y romper el caso normal.

```bash
./run.sh all      # las cuatro
./compare.sh      # la tabla
```

`compare.sh` cruza **dos fuentes**: lo que vio el cliente (k6) y lo que pasó
adentro (Prometheus, consultando la ventana exacta de cada fase). La primera dice
si la hipótesis se sostuvo; la segunda dice por qué. Con una sola, el experimento
no concluye nada accionable.

### Cómo leer el resultado

| Comparación | Qué responde |
|---|---|
| 1 vs 2 | El tamaño del daño. Si el p99 sube mucho más que los 500 ms inyectados, la diferencia es **amplificación**: cola detrás de un lock, no latencia del tercero. |
| 1 vs 3 | Que v2 no empeoró el caso sano. |
| 2 vs 4 | El resultado del experimento. Es el único par que responde la pregunta inicial. |

La relación diagnóstica, que sirve para siempre y no solo para este repo:

```
sección_crítica ≈ permanencia      → no hay contención
sección_crítica ≫ permanencia      → hay cola detrás del lock
permanencia ≈ latencia_proveedor   → hay I/O DENTRO de la sección crítica
```

### Y después: que no vuelva

`ci/chaos-gate.yml` corre el mismo `docker compose` en cada pull request, con los
umbrales de k6 **en modo bloqueante**. El defecto original es exactamente el tipo
de cosa que alguien reintroduce en seis meses con un cambio de tres líneas que
parece inofensivo y que ninguna revisión de código detecta.

Una prueba de resiliencia con la misma autoridad que una prueba unitaria. Ese es,
probablemente, el mejor cierre: la ingeniería del caos no es un evento, es un
control.

---

## Guion para 30 minutos

| Min | Qué | Comando |
|---|---|---|
| 0–3 | El código en pantalla. Preguntar dónde está el problema. Nadie lo ve. | — |
| 3–6 | Prueba de carga normal: todo verde. "Está listo para producción." | `./compare.sh` (fase 1, ya corrida) |
| 6–8 | Escribir la hipótesis en el tablero. Inyectar el fallo. | `./run.sh latency on` |
| 8–13 | Fase 2 en vivo. Ver el colapso mientras corre. | `./run.sh 2` |
| 13–17 | El tablero, de arriba abajo. Llegar a la tarjeta `permanencia ÷ proveedor`. Mostrar `IoInsideLock` disparada en Prometheus. | Grafana + `/alerts` |
| 17–19 | Volver al código con el diagnóstico ya hecho. Ahora sí se ve. | — |
| 19–23 | Un lock protege una transición, no un procedimiento. Leer-calcular-confirmar. | `PaymentsV2.scala` |
| 23–27 | Fase 4 en vivo. Misma latencia inyectada, p99 dentro del SLO. | `./run.sh 4` |
| 27–30 | La tabla comparativa y el gate en CI. La ingeniería del caos como control. | `./compare.sh` |

**Contingencia.** Correr `./run.sh all` la noche anterior y no borrar `results/`.
Si algo falla en vivo, `./compare.sh` sola cuenta la historia completa. Y si
Docker se cae del todo, quedan las cuatro tablas y el tablero en capturas.

### Preguntas que van a salir

- *"¿No basta con un caché?"* — No. El caché reduce la frecuencia del camino
  lento, no su costo cuando ocurre. Y con TTL duro lo concentra: todas las
  peticiones vuelven a origen a la vez. Fase 2 con caché caliente parece sana
  hasta que expira.
- *"¿No basta con un timeout?"* — Acota el daño; no lo elimina. Con un timeout de
  800 ms el techo por cuenta sigue siendo ~1.2 op/s en el peor caso. El timeout
  es necesario y no suficiente.
- *"¿Y si escalo horizontalmente?"* — El lock es por cuenta dentro del proceso.
  Con estado compartido real, sería un lock distribuido y el problema empeora.
  Más réplicas reparten cuentas distintas; la cuenta caliente sigue siendo una.
- *"¿Esto pasa fuera de Cats Effect?"* — Es el mismo defecto que
  `synchronized { httpClient.get(...) }` en Java, o una transacción de base de
  datos abierta mientras se llama a una API externa. El lenguaje cambia; el
  patrón no.
